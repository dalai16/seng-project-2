# SENG201-Project
Ensure Java 11 is installed on the machine

Open the zip folder in a terminal window

Run "java -jar jab330_wth37_SpaceExplorer.jar"
