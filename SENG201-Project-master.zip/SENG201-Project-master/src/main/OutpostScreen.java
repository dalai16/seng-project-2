/**
 * The outpost screen displays all items the crew may buy
 * to restore health, hunger or cure space plague.
 * also displays their current money and items owned.
 * they may sell their items for the same amount of money
 * as the purchase price.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */
package main;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import java.awt.Font;
import javax.swing.SwingConstants;

public class OutpostScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	/**
	 * Stores the currentItem as a string
	 */
	private String currentItem;
	
	/**
	 * OutpostScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public OutpostScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	
	/**
	 * closeWindow disposes the current frame in use
	 */
	public void closeWindow() {
		frame.dispose();
	}
	
	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OutpostScreen window = new OutpostScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OutpostScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {


		frame = new JFrame("Outpost");
		frame.setBounds(100, 100, 477, 353);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		/**
		 * store label
		 */
		JLabel lblShop = new JLabel("Outpost Store");
		lblShop.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblShop.setBounds(47, 0, 95, 34);
		frame.getContentPane().add(lblShop);

		JLabel lblInventory = new JLabel("Inventory");
		lblInventory.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblInventory.setBounds(293, 21, 75, 24);
		frame.getContentPane().add(lblInventory);
		/**
		 * displays current money
		 */
		JLabel lblMoney = new JLabel("Money: $\r\n" + manager.getCrew().getMoneyAmount());
		lblMoney.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblMoney.setBounds(183, 210, 74, 28);
		frame.getContentPane().add(lblMoney);

		/**
		 * returns to game screen
		 */
		JButton btnBack = new JButton("Back");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				closeWindow();
				manager.launchGameScreen();
			}
		});
		btnBack.setBounds(171, 256, 86, 38);
		frame.getContentPane().add(btnBack);
		/**
		 * shows all obtainable items in inventory
		 */
		JList<String> listInventory = new JList<String>();
		listInventory.setFont(new Font("Tahoma", Font.PLAIN, 12));
		listInventory.setModel(new AbstractListModel<String>() {
			private static final long serialVersionUID = 1L;
			String[] values = new String[] {"Plague Cure", "Plaster", "Bandage", "Medkit", "Nutrition Bar", "Rice", "Chips", "Hamburger", "Ramen", "Brownies"};
			public int getSize() {
				return values.length;
			}
			public String getElementAt(int index) {
				return values[index];
			}
		});
		listInventory.setBounds(293, 56, 89, 170);
		frame.getContentPane().add(listInventory);
		
		/**
		 * shows all buyable items in shop
		 */
		JList<String> listShop = new JList<String>();
		listShop.setFont(new Font("Tahoma", Font.PLAIN, 12));
		listShop.setModel(new AbstractListModel<String>() {
			private static final long serialVersionUID = 1L;
			String[] values = new String[] {"Plague Cure", "Plaster", "Bandage", "Medkit", "Nutrition Bar", "Rice", "Chips", "Hamburger", "Ramen", "Brownies"};
			public int getSize() {
				return values.length;
			}
			public String getElementAt(int index) {
				return values[index];
			}
		});
		listShop.setSelectedValue("Plague Cure", false);
		listShop.setBounds(35, 68, 74, 170);
		frame.getContentPane().add(listShop);
		
		/**
		 * shows the amount of each item the crew owns
		 */
		JLabel lblQuantities = new JLabel("<html>" + manager.getPlaguecurecount() + "<br/>"
				+ manager.getPlastercount() + "<br/>" + manager.getBandagecount() + "<br/>" + manager.getMedkitcount() + "<br/>"
				+ manager.getNutritionbarcount() + "<br/>" + manager.getRicecount() + "<br/>" + manager.getChipscount() + "<br/>"
				+ manager.getHamburgercount() + "<br/>" + manager.getRamencount() + "<br/>" + manager.getBrowniescount() + "\r\n</html>");
		lblQuantities.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblQuantities.setBounds(392, 43, 59, 195);
		frame.getContentPane().add(lblQuantities);
		
		/**
		 * allows crew to purchase a selected item in exchange for money.
		 * item is added to inventory. item count and money is updated.
		 * if can't afford, message prompt
		 */
		JButton btnPurchse = new JButton("Purchase");
		btnPurchse.setFont(new Font("Tahoma", Font.PLAIN, 12));
		String medicalitems = "Plague Cure Plaster Bandage Medkit";
		btnPurchse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String item = listShop.getSelectedValue();
				if (medicalitems.contains(item)) {
					Medical medicalitem = new Medical(item);
					int cost = medicalitem.getCost();
					if (manager.getCrew().getMoneyAmount() - cost >= 0) {
						manager.getCrew().addMedicalList(medicalitem);
						currentItem = medicalitem.toString();
						manager.getCrew().setMoneyAmount((manager.getCrew().getMoneyAmount() - cost));
					}
					else {
						JOptionPane.showMessageDialog(null, "Not enough money");
					}
				}
				else {
					Food fooditem = new Food(item);
					int cost = fooditem.getCost();
					if (manager.getCrew().getMoneyAmount() - cost >= 0) {
						manager.getCrew().addFoodList(fooditem);
						currentItem = fooditem.toString();
						manager.getCrew().setMoneyAmount((manager.getCrew().getMoneyAmount() - cost));
					}
					else {
						JOptionPane.showMessageDialog(null, "Not enough money");
						}
				}

				lblMoney.setText("Money: $" + manager.getCrew().getMoneyAmount());

				if (currentItem == "Ramen") {
					manager.setRamencount(manager.getRamencount() + 1);
				}
				else if (currentItem == "Brownies") {
					manager.setBrowniescount(manager.getBrowniescount() + 1);
				}
				else if (currentItem == "Chips") {
					manager.setChipscount(manager.getChipscount() + 1);
				}
				else if (currentItem == "Rice") {
					manager.setRicecount (manager.getRicecount() + 1);
				}
				else if (currentItem == "Hamburger") {
					manager.setHamburgercount(manager.getHamburgercount() + 1);
				}
				else if (currentItem == "Nutrition Bar") {
					manager.setNutritionbarcount(manager.getNutritionbarcount() + 1);
				}
				else if (currentItem == "Plague Cure") {
					manager.setPlaguecurecount(manager.getPlaguecurecount() + 1);
				}
				else if (currentItem == "Plaster") {
					manager.setPlastercount(manager.getPlastercount() + 1);
				}
				else if (currentItem == "Medkit") {
					manager.setMedkitcount(manager.getMedkitcount() + 1);
				}
				else if (currentItem == "Bandage") {
					manager.setBandagecount(manager.getBandagecount() + 1);
				}

				lblQuantities.setText("<html>" + manager.getPlaguecurecount() + "<br/>"
						+ manager.getPlastercount() + "<br/>" + manager.getBandagecount() + "<br/>" + manager.getMedkitcount() + "<br/>"
						+ manager.getNutritionbarcount() + "<br/>" + manager.getRicecount() + "<br/>" + manager.getChipscount() + "<br/>"
						+ manager.getHamburgercount() + "<br/>" + manager.getRamencount() + "<br/>" + manager.getBrowniescount() + "\r\n</html>");
			}
		});

		btnPurchse.setBounds(35, 249, 89, 53);
		frame.getContentPane().add(btnPurchse);
		/**
		 * shows the prices of each item in the outpost store
		 * 
		 */
		JLabel lblShopPrices = new JLabel("<html>$ 50 <br/>$ 20 <br/>$ 40 <br/>$ 85 <br/>$ 30 <br/>$ 50 <br/>$ 10 <br/>$ 60 <br/>$ 40 <br/>$ 20 \r\n</html>");
		lblShopPrices.setVerticalAlignment(SwingConstants.TOP);
		lblShopPrices.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblShopPrices.setBounds(120, 67, 53, 170);
		frame.getContentPane().add(lblShopPrices);

		/**
		 * label quantity
		 */
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblQuantity.setBounds(380, 27, 59, 18);
		frame.getContentPane().add(lblQuantity);
		
		/**
		 * sell button allows crew to sell an item for the same money 
		 * value as purchase price if owned.
		 * item is taken out of iventory and money is earned, label is updated.
		 */
		JButton btnSell = new JButton("Sell");
		btnSell.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSell.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String item = listInventory.getSelectedValue();
				ArrayList<Medical> arraymedical = manager.getCrew().getMedicalList();
				ArrayList<Food> arrayfood = manager.getCrew().getFoodList();
				Medical med_item = new Medical(item);
				Food food_item = new Food(item);
				currentItem = med_item.toString();
				if (medicalitems.contains(currentItem)) {
					if (currentItem == "Plague Cure") {
						if (manager.getPlaguecurecount() == 0) {
							JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
							
						}
						else {
							manager.setPlaguecurecount(manager.getPlaguecurecount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + med_item.getCost());
							for (Medical object: arraymedical) {
								if (object.toString() == currentItem) {
									arraymedical.remove(object);
									break;
							}
							}
						}
						}
					else if (currentItem == "Plaster") {
						if (manager.getPlastercount() == 0) {
							JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
							
						}
						else {
						manager.setPlastercount(manager.getPlastercount() - 1);
						manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + med_item.getCost());
						for (Medical object: arraymedical) {
							if (object.toString() == currentItem) {
								arraymedical.remove(object);
								break;
							}
						}
						}
					}
					else if (currentItem == "Medkit") {
						if (manager.getMedkitcount() == 0) {
							JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
							
						}
						else {
						manager.setMedkitcount(manager.getMedkitcount() - 1);
						manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + med_item.getCost());
						for (Medical object: arraymedical) {
							if (object.toString() == currentItem) {
								arraymedical.remove(object);
								break;
							}
							}
						}
							}
					else if (currentItem == "Bandage") {
						if (manager.getBandagecount() == 0) {
							JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
							
						}
						else {
						manager.setBandagecount(manager.getBandagecount() - 1);
						manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + med_item.getCost());
						for (Medical object: arraymedical) {
							if (object.toString() == currentItem) {
								arraymedical.remove(object);
								break;
							}
							}
						}
					}
				}
					
				else {
					
						if (currentItem == "Ramen") {
							if (manager.getRamencount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setRamencount(manager.getRamencount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
							}
						else if (currentItem == "Brownies") {
							if (manager.getBrowniescount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setBrowniescount(manager.getBrowniescount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
							}
						else if (currentItem == "Chips") {
							if (manager.getChipscount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setChipscount(manager.getChipscount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
								}
						else if (currentItem == "Rice") {
							if (manager.getRicecount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setRicecount (manager.getRicecount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
								}
						else if (currentItem == "Hamburger") {
							if (manager.getHamburgercount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setHamburgercount(manager.getHamburgercount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
								}
						else if (currentItem == "Nutrition Bar") {
							if (manager.getNutritionbarcount() == 0) {
								JOptionPane.showMessageDialog(null, "Can't sell item if you don't own item 4Head!");
								
							}
							else {
							manager.setNutritionbarcount(manager.getNutritionbarcount() - 1);
							manager.getCrew().setMoneyAmount(manager.getCrew().getMoneyAmount() + food_item.getCost());
							for (Food object: arrayfood) {
								if (object.toString() == currentItem) {
									arrayfood.remove(object);
									break;
								}
								}
							}
								}
					}

				lblMoney.setText("Money: $" + manager.getCrew().getMoneyAmount());
				lblQuantities.setText("<html>" + manager.getPlaguecurecount() + "<br/>"
						+ manager.getPlastercount() + "<br/>" + manager.getBandagecount() + "<br/>" + manager.getMedkitcount() + "<br/>"
						+ manager.getNutritionbarcount() + "<br/>" + manager.getRicecount() + "<br/>" + manager.getChipscount() + "<br/>"
						+ manager.getHamburgercount() + "<br/>" + manager.getRamencount() + "<br/>" + manager.getBrowniescount() + "\r\n</html>");
					}
		});
		btnSell.setBounds(304, 249, 89, 48);
		frame.getContentPane().add(btnSell);
		/**
		 * label price
		 */
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblPrice.setBounds(125, 35, 53, 29);
		frame.getContentPane().add(lblPrice);
		/**
		 * item label
		 */
		JLabel lblItems = new JLabel("Items");
		lblItems.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblItems.setBounds(35, 35, 66, 29);
		frame.getContentPane().add(lblItems);


	}
}
