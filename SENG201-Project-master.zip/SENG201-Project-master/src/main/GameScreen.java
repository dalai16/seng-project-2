/**
 * GameScreen is a graphical interface.
 * This Screen is the main game environment
 * which contains JButtons, JTextFields, and
 * JLabels. Also contains functionality in
 * which allows the program to run.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;

public class GameScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	
	/**
	 * GameScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public GameScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	
	/**
	 * closeWindow disposes the current frame in use
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GameScreen window = new GameScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GameScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Game Screen");
		frame.setBounds(100, 100, 625, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * Shows current status of selected spaceship name and shield and the 
		 * current players name, class, health, hunger, tiredness, and if diseased
		 */
		JLabel lblStats = new JLabel("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(0) + "<br/><br/> Class: " + manager.getCrewClass(0) + "<br/><br/>Health: " + manager.getCrewHealth(0) + "<br/><br/> Hunger: " + manager.getCrewHunger(0) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(0) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
		lblStats.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblStats.setBounds(20, 99, 217, 312);
		frame.getContentPane().add(lblStats);
		
		/**
		 * JLabel which shows the current day
		 */
		JLabel dayCount = new JLabel("Day: " + manager.getCurrentDay());
		dayCount.setFont(new Font("Tahoma", Font.PLAIN, 12));
		dayCount.setBounds(240, 10, 100, 20);
		frame.getContentPane().add(dayCount);
		
		/**
		 * JButton that displays the current planet landed on
		 */
		JLabel lblPlanet = new JLabel("Current Planet: " + manager.getCurrentPlanet());
		lblPlanet.setBounds(350, 10, 200, 20);
		frame.getContentPane().add(lblPlanet);
		
		/**
		 * JButton initializes outpost screen when clicked and closes the current screen
		 */
		JButton toOutpost = new JButton("To Outpost");
		toOutpost.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeWindow();
				manager.launchOutpostScreen();
			}
		});
		toOutpost.setFont(new Font("Tahoma", Font.PLAIN, 13));
		toOutpost.setBounds(125, 10, 106, 78);
		frame.getContentPane().add(toOutpost);

		/**
		 * JLabel that shows the remaining action points of the current crew member
		 */
		JLabel lblActionPoints = new JLabel("Action Points Remaining: " + manager.getCrewActionPoints(0));
		lblActionPoints.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblActionPoints.setBounds(308, 160, 291, 26);
		frame.getContentPane().add(lblActionPoints);
		
		/**
		 * JButton initializes inventory screen when clicked and closes the current screen
		 */
		JButton btnInventory = new JButton("Inventory");
		btnInventory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.launchInventoryScreen();
				closeWindow();
			}
		});
		btnInventory.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnInventory.setBounds(10, 10, 106, 78);
		frame.getContentPane().add(btnInventory);
		
		/**
		 * is piece found or not
		 */
		JLabel lblPieceFound = new JLabel("Piece found on planet: " + manager.getAlreadyFound());
		lblPieceFound.setBounds(347, 41, 177, 20);
		frame.getContentPane().add(lblPieceFound);
		
		/** 
		 * JButton which when clicked switches displayed crew member to perform actions
		 * This button also updates text within lblStats and lblActionPoints to
		 * display the current crew member
		 */
		JButton btnPlayer1 = new JButton(manager.getCrewName(0));
		btnPlayer1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.setCurrentMember(0);
				lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(0) + "<br/><br/> Class: " + manager.getCrewClass(0) + " <br/><br/>Health: " + manager.getCrewHealth(0) + "<br/><br/> Hunger: " + manager.getCrewHunger(0) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(0) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(0) + "<br/><br/> </html>");
				lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(0));
			}
		});
		btnPlayer1.setBounds(10, 160, 129, 23);
		frame.getContentPane().add(btnPlayer1);
		
		/** 
		 * JButton which when clicked switches displayed crew member to perform actions
		 * This button also updates text within lblStats and lblActionPoints to
		 * display the current crew member
		 */
		JButton btnPlayer2 = new JButton(manager.getCrewName(1));
		btnPlayer2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.setCurrentMember(1);
				lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(1) + "<br/><br/> Class: " + manager.getCrewClass(1) + "<br/><br/> Health: " + manager.getCrewHealth(1) + "<br/><br/> Hunger: " + manager.getCrewHunger(1) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(1) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(1) + "<br/><br/> </html>");
				lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(1));
			}
		});
		btnPlayer2.setBounds(149, 160, 130, 23);
		frame.getContentPane().add(btnPlayer2);
		
		/** 
		 * JButton which when clicked switches displayed crew member to perform actions
		 * This button also updates text within lblStats and lblActionPoints to
		 * display the current crew member
		 */
		JButton btnPlayer3 = new JButton();
		btnPlayer3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.setCurrentMember(2);
				lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(2) + "<br/><br/> Class: " + manager.getCrewClass(2) + "<br/><br/> Health: " + manager.getCrewHealth(2) + "<br/><br/> Hunger: " + manager.getCrewHunger(2) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(2) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(2) + "<br/><br/> </html>");
				lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(2));
			}
		});
		btnPlayer3.setBounds(10, 189, 129, 23);
		frame.getContentPane().add(btnPlayer3);

		if (manager.getCrewSize() < 3) {
			btnPlayer3.setVisible(false);
		}
		else {
			btnPlayer3.setText(manager.getCrewName(2));
		}
		
		/** 
		 * JButton which when clicked switches displayed crew member to perform actions
		 * This button also updates text within lblStats and lblActionPoints to
		 * display the current crew member
		 */
		JButton btnPlayer4 = new JButton();
		btnPlayer4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.setCurrentMember(3);
				lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(3) +"<br/><br/> Class: " + manager.getCrewClass(3) + "<br/><br/>Health: " + manager.getCrewHealth(3) + "<br/><br/> Hunger: " + manager.getCrewHunger(3) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(3) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(3) + "<br/><br/> </html>");
				lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(3));
			}
		});
		btnPlayer4.setBounds(149, 189, 130, 23);
		frame.getContentPane().add(btnPlayer4);

		if (manager.getCrewSize() < 4) {
			btnPlayer4.setVisible(false);
		}
		else {
			btnPlayer4.setText(manager.getCrewName(3));
		}

		/** current member is deducted an action point to forage the current planet for items.
		 * a random event will be invoked and the crew member can find one of: a health or medical item, a random amount of money,
		 * a transporter piece of one hasnt been found on the planet yet, or nothing. the item chances are influenced 
		 * by the current crew member's foraging level.  
		 */
		JButton btnSearch = new JButton("Search Planet");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(manager.getCrewActionPoints(manager.getCurrentMember()) == 0) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " has no action points left.");
				}
				else if(manager.getCrewTiredness(manager.getCurrentMember()) == 0) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " is too tired. they must rest");
				}
				else if(manager.getCrewActionPoints(manager.getCurrentMember()) - 1 != -1 ) {
					manager.setCrewActionPoints(manager.getCurrentMember(),  manager.getCrewActionPoints(manager.getCurrentMember()) - 1);
					lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(manager.getCurrentMember()) + "<br/><br/> Class: " + manager.getCrewClass(manager.getCurrentMember()) + "<br/><br/> Health: " + manager.getCrewHealth(manager.getCurrentMember()) + "<br/><br/> Hunger: " + manager.getCrewHunger(manager.getCurrentMember()) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(manager.getCurrentMember()) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
					lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(manager.getCurrentMember()));
					Random random = new Random();
					switch(random.nextInt(manager.getForagingLevel(manager.getCurrentMember()) + 4) +1 ) {
					case 1:
						switch(random.nextInt(4)+1) {
						case 1:
							Medical plague = new Medical("Plague Cure");
							manager.getCrew().addMedicalList(plague);
							manager.setPlaguecurecount(manager.getPlaguecurecount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Plague Cure");
							break;
						case 2:
							Medical medkit = new Medical("Medkit");
							manager.getCrew().addMedicalList(medkit);
							manager.setMedkitcount(manager.getMedkitcount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Medkit");
							break;
						case 3:
							Medical bandage = new Medical("Bandage");
							manager.getCrew().addMedicalList(bandage);
							manager.setBandagecount(manager.getBandagecount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Bandage");
							break;
						case 4:
							Medical plaster = new Medical("Plaster");
							manager.getCrew().addMedicalList(plaster);
							manager.setPlastercount(manager.getPlastercount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Plaster");
							break;
						}
						break;
					case 2:
						switch(random.nextInt(6)+1) {
						case 1:
							Food ramen = new Food("Ramen");
							manager.getCrew().addFoodList(ramen);
							manager.setRamencount(manager.getRamencount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found some Ramen");
							break;
						case 2:
							Food brownie = new Food("Brownies");
							manager.getCrew().addFoodList(brownie);
							manager.setBrowniescount(manager.getBrowniescount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found some Brownies");
							break;
						case 3:
							Food chip = new Food("Chips");
							manager.getCrew().addFoodList(chip);
							manager.setChipscount(manager.getChipscount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found some Chips");
							break;
						case 4:
							Food rice = new Food("Rice");
							manager.getCrew().addFoodList(rice);
							manager.setRicecount (manager.getRicecount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found some Rice");
							break;
						case 5:
							Food hamburger = new Food("Hamburger");
							manager.getCrew().addFoodList(hamburger);
							manager.setHamburgercount(manager.getHamburgercount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Hamburger");
							break;
						case 6:
							Food nutritionbar = new Food("Nutrition Bar");
							manager.getCrew().addFoodList(nutritionbar);
							manager.setNutritionbarcount(manager.getNutritionbarcount() + 1);
							JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Bandage");
							break;
						}
						break;
					case 3:
						if(manager.getAlreadyFound() == true) {
							JOptionPane.showMessageDialog(null, "Nothing was found.");
							break;
						}
						else {
						manager.setCurrentPieces(manager.getCurrentPieces() + 1);
						manager.setAlreadyFound(true);
						lblPieceFound.setText("Piece found on planet: " + manager.getAlreadyFound());
						JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Tansporter Piece");
						if(manager.getCurrentPieces() == manager.getPiecesAmount()) {
							manager.launchEndScreen();
							closeWindow();
						}
						break;
						}
					case 4:
						int num = (random.nextInt(200)+50);
						manager.setMoneyAmount(manager.getCurrentMoney() + num);
						JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found $" + num);
						break;
					case 5:
						JOptionPane.showMessageDialog(null, "Nothing was found.");
						break;
					case 6:
					case 7:
					case 8:
					case 9:
						if(manager.getAlreadyFound() == true) {
							JOptionPane.showMessageDialog(null, "Nothing was found.");
							break;
						}
						else {
						manager.setCurrentPieces(manager.getCurrentPieces() + 1);
						manager.setAlreadyFound(true);
						lblPieceFound.setText("Piece found on planet: " + manager.getAlreadyFound());
						JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " found a Tansporter Piece");
						if(manager.getCurrentPieces() == manager.getPiecesAmount()) {
							manager.launchEndScreen();
							closeWindow();
						}
						break;
						}
					}
				}
			}
		});
		btnSearch.setBounds(329, 181, 270, 35);
		frame.getContentPane().add(btnSearch);
		
		/**
		 * JButton in which the current member can sleep to restore 50 tiredness at the
		 *  cost of 1 action point and tiredness can't increase over 100 tiredness.
		 * if no action points left player can't sleep
		 * if tiredness is 100 player cant't sleep
		 * updates text throughout program if sleep was successful
		 */
		JButton btnSleep = new JButton("Sleep");
		btnSleep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(manager.getCrewActionPoints(manager.getCurrentMember()) == 0) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " has no action points left.");
				}
				else if(manager.getCrewTiredness(manager.getCurrentMember()) == 100) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " is already fully rested.");
				}
				else {
					if(manager.getCrewTiredness(manager.getCurrentMember()) + 50 > 100) {
						manager.setCrewTiredness(manager.getCurrentMember(), 100);
					}
					else if (manager.getCrewTiredness(manager.getCurrentMember()) + 50 <= 100) {
						manager.setCrewTiredness(manager.getCurrentMember(), manager.getCrewTiredness(manager.getCurrentMember()) + 50);
					}
					manager.setCrewActionPoints(manager.getCurrentMember(),  manager.getCrewActionPoints(manager.getCurrentMember()) - 1);
					lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(manager.getCurrentMember()) + "<br/><br/> Class: " + manager.getCrewClass(manager.getCurrentMember()) + "<br/><br/> Health: " + manager.getCrewHealth(manager.getCurrentMember()) + "<br/><br/> Hunger: " + manager.getCrewHunger(manager.getCurrentMember()) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(manager.getCurrentMember()) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
					lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(manager.getCurrentMember()));
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " got some rest.");
				}
			}
		});
		btnSleep.setBounds(329, 214, 270, 35);
		frame.getContentPane().add(btnSleep);
		
		/** 
		 * current crew member uses an action point to restore the ship's shield if shield is damaged.
		 * member's tiredness is reduced and shield repaired is correlated to member's repairing level.
		 */
		JButton btnRepair = new JButton("Repair Ship");
		btnRepair.setToolTipText("<html>Takes 1 action point.<br>Repairs ship depending on reparing level.</html>");
		btnRepair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(manager.getCrewActionPoints(manager.getCurrentMember()) - 1 == -1) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " has no action points left.");
				}
				else if(manager.getCrewTiredness(manager.getCurrentMember()) == 0) {
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " is too tired. they must rest");
				}
				else if(manager.getShipShield() == 100) {
					JOptionPane.showMessageDialog(null, manager.getShipName() + " currently has full shield.");
				}
				else {
					if(manager.getShipShield() + manager.getRepairLevel(manager.getCurrentMember()) * 10 > 100) {
						manager.setShipShield(100);
						manager.setCrewTiredness(manager.getCurrentMember(), manager.getCrewTiredness(manager.getCurrentMember()) - (60 / manager.getRepairLevel(manager.getCurrentMember())));
					}
					else if (manager.getShipShield() + manager.getRepairLevel(manager.getCurrentMember()) * 10 <= 100) {
						manager.setShipShield(manager.getShipShield() + manager.getRepairLevel(manager.getCurrentMember()) * 10);
						manager.setCrewTiredness(manager.getCurrentMember(), manager.getCrewTiredness(manager.getCurrentMember()) - (60 / manager.getRepairLevel(manager.getCurrentMember())));
					}
					manager.setCrewActionPoints(manager.getCurrentMember(),  manager.getCrewActionPoints(manager.getCurrentMember()) - 1);
					lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(manager.getCurrentMember()) + "<br/><br/> Class: " + manager.getCrewClass(manager.getCurrentMember()) + "<br/><br/> Health: " + manager.getCrewHealth(manager.getCurrentMember()) + "<br/><br/> Hunger: " + manager.getCrewHunger(manager.getCurrentMember()) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(manager.getCurrentMember()) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
					lblActionPoints.setText("Action Points Remaining: " + manager.getCrewActionPoints(manager.getCurrentMember()));
					JOptionPane.showMessageDialog(null, manager.getCrewName(manager.getCurrentMember()) + " repaired " + manager.getShipName() + "'s shield");
				}
			}
		});
		btnRepair.setBounds(329, 246, 270, 35);
		frame.getContentPane().add(btnRepair);
		
		/** 
		 * checks whether crew is eligible to fly to a new planet
		 * ie; at least 2 different crew members have 1 or more action points left. 
		 * if eligible, then open pilot screen
		 * else invalid action message popup
		 */
		JButton btnPilotShip = new JButton("Pilot Ship");
		btnPilotShip.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int count = 0;
				for (CrewMembers member: manager.getCrew().getCrewList()) {
					if(member.getActionPoints() > 0 && member.getHealth() > 0) {
						count ++;
					}
				}
				if (count > 1) {
					closeWindow();
					manager.launchPilotScreen();
				}
				else {
					JOptionPane.showMessageDialog(null, "Not enough action points. Piloting the ship requires at least 2 crew members to have at least 1 action point each");
				}
			}
		});
		btnPilotShip.setBounds(329, 278, 270, 35);
		frame.getContentPane().add(btnPilotShip);
		
		/**
		 * JButton to advance to a new day
		 * We check lots of different variables once btnNextDay is clicked
		 */
		JButton btnNextDay = new JButton("Next Day");
		btnNextDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/** 
				 * checks if current day is equal to the amount of selected days when next day is pressed
				 * if it is, end game and display end screen. Else, move onto next day and invoke random events
				 */
				if(manager.getCurrentDay() == manager.getAdventureDays()) {
					manager.launchEndScreen();
					closeWindow();
				}
				else {
				for (CrewMembers member: manager.getCrew().getCrewList()) {
					member.setActionPoints(2);
				}
				Random random = new Random();
				switch(random.nextInt(6)+1) {
				case 1:
					switch(random.nextInt(2)+1) {
					case 1:
						if(manager.getMedicalList().size() > 0) {
							Random rand = new Random();
							Medical stolen = manager.getMedicalList().get(rand.nextInt(manager.getMedicalList().size()));
							manager.getMedicalList().remove(stolen);
							manager.getCrew().setMedicalList(manager.getMedicalList());
							JOptionPane.showMessageDialog(null, "An Alien pirate has boared the ship and stole a " + stolen);
							break;
						}
					case 2:
						if(manager.getFoodList().size() > 0) {
							Random rand = new Random();
							Food stolen = manager.getFoodList().get(rand.nextInt(manager.getFoodList().size()));
							manager.getFoodList().remove(stolen);
							manager.getCrew().setFoodList(manager.getFoodList());
							JOptionPane.showMessageDialog(null, "An Alien pirate has boared the ship and stole a " + stolen);
							break;
						}
					}
				case 2:
					switch(random.nextInt(manager.getCrewSize())){
					case 0:
						if(manager.getIsDiseased(0) == false) {
							manager.setIsDiseased(0, true);
							JOptionPane.showMessageDialog(null, manager.getCrewName(0) + " has come down with space plague.");
						}
						break;
					case 1:
						if(manager.getIsDiseased(1) == false) {
							manager.setIsDiseased(1, true);
							JOptionPane.showMessageDialog(null, manager.getCrewName(1) + " has come down with space plague.");
						}
						break;
					case 2:
						if(manager.getIsDiseased(2) == false) {
							manager.setIsDiseased(2, true);
							JOptionPane.showMessageDialog(null, manager.getCrewName(2) + " has come down with space plague.");
						}
						break;
					case 3:
						if(manager.getIsDiseased(3) == false) {
							manager.setIsDiseased(3, true);
							JOptionPane.showMessageDialog(null, manager.getCrewName(3) + " has come down with space plague.");
						}
						break;
					}
				case 3:
					int damage = (int)((Math.floor((((float) 25 / manager.getShipShield())) * 12 + 20)));
					if (manager.getShipShield() == 0 && manager.getShipShield() - damage < 0) {
						JOptionPane.showMessageDialog(null, manager.getShipName() + " has taken fatal damage.");
						closeWindow();
						manager.launchEndScreen();
					}
					else {
						if (manager.getShipShield() - damage < 0) {
							manager.setShipShield(0);
						}
						else {
							manager.setShipShield(manager.getShipShield() - damage);
						}
						JOptionPane.showMessageDialog(null, manager.getShipName() + " has entered a asteroid belt and has decreased the shield amount by " + damage);
						break;
					}
					break;
				case 4:
					break;
				}
				// updates current day and screen
				manager.setCurrentDay(manager.getCurrentDay() + 1);
				dayCount.setText("Day: " + String.valueOf(manager.getCurrentDay()));
				lblActionPoints.setText("Action Points Remaining: 2");
				for (CrewMembers member: manager.getCrew().getCrewList()) {
					// decrease each crew members' hunger and tiredness each day and sickens diseased members
					member.setHunger(member.getHunger() - 20);
					member.setTiredness(member.getTiredness() - 30);
					if(member.toString() == "Captain") {
						member.setTiredness(member.getTiredness() - 10);
					}
					if (member.getDiseased()) {
						member.setDaysPlagued(member.getDaysPlagued() + 1);
						member.setHealth(member.getHealth() - 20 * member.getDaysPlagued());
					}
					if (member.getHunger() == 0 && member.getHealth() != 0) {
						JOptionPane.showMessageDialog(null, member.getName() + " took 20 damage from being hungry.");
						member.setHealth(member.getHealth() - 20);
					}
					// checks whether each members' health is below or at 0 (ie; dead) then output a death message and remove member button
					if (manager.getCrewHealth(0) <= 0) {
						if (btnPlayer1.isEnabled()) {
						JOptionPane.showMessageDialog(null, manager.getCrewName(0) + " has died from space plague");
						btnPlayer1.setEnabled(false);
						btnPlayer1.setText("Dead");
						}
					}
		
					if (manager.getCrewHealth(1) <= 0) {
						if (btnPlayer2.isEnabled()) {
							JOptionPane.showMessageDialog(null, manager.getCrewName(1) + " has died from space plague");
							btnPlayer2.setEnabled(false);
							btnPlayer2.setText("Dead");
							}
					}
					if (manager.getCrewSize() >= 3) {
						if (manager.getCrewHealth(2) <= 0) {
							if (btnPlayer3.isEnabled()) {
								JOptionPane.showMessageDialog(null, manager.getCrewName(2) + " has died from space plague");
								btnPlayer3.setEnabled(false);
								btnPlayer3.setText("Dead");
								}
					}
					}
					if (manager.getCrewSize() == 4) {
						if (manager.getCrewHealth(3) <= 0) {
							if (btnPlayer4.isEnabled()) {
								JOptionPane.showMessageDialog(null, manager.getCrewName(3) + " has died from space plague");
									btnPlayer4.setEnabled(false);
									btnPlayer4.setText("Dead");
								}
					}
					}

				}

				JOptionPane.showMessageDialog(null, "Day: " + manager.getCurrentDay());
				}
				//when a crew member dies, set the current crew member to an alive one.
				int count = 0;
				boolean alive = false;
				for (CrewMembers member: manager.getCrew().getCrewList()) {
					if (member.getHealth() > 0) {
						manager.setCurrentMember(count);
						alive = true;
						break;
					}
					count ++;
				}
					if (!alive) {
						JOptionPane.showMessageDialog(null, manager.getShipName() + " has no crew members alive. Game over!");
						manager.launchEndScreen();
						closeWindow();
					}
					lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(manager.getCurrentMember()) + "<br/><br/> Class: " + manager.getCrewClass(manager.getCurrentMember()) + "<br/><br/> Health: " + manager.getCrewHealth(manager.getCurrentMember()) + "<br/><br/> Hunger: " + manager.getCrewHunger(manager.getCurrentMember()) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(manager.getCurrentMember()) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
				lblStats.setText("<html> Ship name: " + manager.getShipName() + "<br/><br/> Ship Shield: " + manager.getShipShield() + "<br/><br/><br/><br/><br/><br/><br/> Crew Member Name: " + manager.getCrewName(manager.getCurrentMember()) + "<br/><br/> Class: " + manager.getCrewClass(manager.getCurrentMember()) + "<br/><br/> Health: " + manager.getCrewHealth(manager.getCurrentMember()) + "<br/><br/> Hunger: " + manager.getCrewHunger(manager.getCurrentMember()) + "<br/><br/> Tiredness: " + manager.getCrewTiredness(manager.getCurrentMember()) + "<br/><br/> Has Space plague: " + manager.getIsDiseased(manager.getCurrentMember()) + "<br/><br/> </html>");
				manager.setAlreadyFound(false);
				lblPieceFound.setText("Piece found on planet: " + manager.getAlreadyFound());
			}
		});
		/**
		 * when game screen is initialized, show only the buttons of alive crew members
		 */
		if (manager.getCrewHealth(0) <= 0) {
			btnPlayer1.setEnabled(false);
			btnPlayer1.setText("Dead");
		}
		if (manager.getCrewHealth(1) <= 0) {
			btnPlayer2.setEnabled(false);
			btnPlayer2.setText("Dead");
		}
		if (manager.getCrewSize() >= 3) {
			if (manager.getCrewHealth(2) <= 0) {
				btnPlayer3.setEnabled(false);
				btnPlayer3.setText("Dead");
			}
		}
		if (manager.getCrewSize() == 4) {
			if (manager.getCrewHealth(3) <= 0) {
				btnPlayer4.setEnabled(false);
				btnPlayer4.setText("Dead");
			}
		}
		btnNextDay.setBounds(329, 308, 270, 34);
		frame.getContentPane().add(btnNextDay);
		
	}
}
