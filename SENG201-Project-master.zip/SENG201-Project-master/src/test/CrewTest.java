/**
 * Test cases for the Crew class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;


import org.junit.jupiter.api.Test;

import main.Crew;
import main.CrewMembers;
import main.Medical;

class CrewTest {

	@Test
	void testSetShipNameReturnsGetShipName() {
		Crew crew = new Crew();
		crew.setShipName("voyager");
		assertEquals(crew.getShipName(), "voyager");
	}
	
	@Test
	void testSetMoneyAmountReturnsGetMoneyAmount() {
		Crew crew = new Crew();
		crew.setMoneyAmount(1);
		assertEquals(crew.getMoneyAmount(), 1);
	}
	
	@Test
	void testSetPartsAmountReturnsGetPartsAmount() {
		Crew crew = new Crew();
		crew.setPartsAmount(2);
		assertEquals(crew.getPartsAmount(), 2);
	}
	
	@Test
	void testSetShieldAmountReturnsGetShieldAmount() {
		Crew crew = new Crew();
		crew.setShieldAmount(100);
		assertEquals(crew.getShieldAmount(), 100);
	}
	
	@Test
	void testAddCrewMembersReturnsGetCrewMembers() {
		Crew crew = new Crew();
		CrewMembers member = new CrewMembers("jack", 5, 5, 100);
		crew.addCrewMember(member);
		assertSame(member, crew.getCrewList().get(0));
	}

	@Test
	void testAddMedicalListReturnsGetMedicalList() {
		Crew crew = new Crew();
		Medical cure = new Medical("Plague Cure");
		crew.getMedicalList().add(cure);
		assertSame(cure, crew.getMedicalList().get(0));
	}
	
}
