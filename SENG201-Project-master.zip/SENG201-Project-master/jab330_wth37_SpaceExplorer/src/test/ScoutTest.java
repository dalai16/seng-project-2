/**
 * Test cases for the Scout class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Scout;

class ScoutTest {

	@Test
	void testConstructor() {
		Scout scout = new Scout("jack");
        assertEquals(scout.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Scout scout = new Scout("jack");
		assertEquals(scout.toString(), "Scout");
	}

}
