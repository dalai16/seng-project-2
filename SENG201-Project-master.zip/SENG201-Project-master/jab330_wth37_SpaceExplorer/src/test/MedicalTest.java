/**
 * Test cases for the Medical class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Medical;

class MedicalTest {

	@Test
	void testConstructor() {
		Medical medical = new Medical("Bandage");
        assertEquals(medical.toString(), "Bandage");
	}
	
	@Test
	void testGetCost() {
		Medical medical = new Medical("Bandage");
		assertEquals(medical.getCost(), 40);
		Medical medical1 = new Medical("Plaster");
		assertEquals(medical1.getCost(), 20);
		Medical medical2 = new Medical("Plague Cure");
		assertEquals(medical2.getCost(), 50);
		Medical medical3 = new Medical("Medkit");
		assertEquals(medical3.getCost(), 85);
	}
}
