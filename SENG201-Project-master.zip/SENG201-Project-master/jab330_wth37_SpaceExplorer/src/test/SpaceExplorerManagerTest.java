/**
 * Test cases for the SpaceExplorerManager class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.SpaceExplorerManager;

public class SpaceExplorerManagerTest {
	
	SpaceExplorerManager manager = new SpaceExplorerManager();
	
	@Test
	void testSetPlagueCountReturnsGetPlagueCount() {
		manager.setPlaguecurecount(1);
		 assertEquals(manager.getPlaguecurecount(), 1);
	}
	
	@Test
	void testSetPlasterCountReturnsGetPlasterCount() {
		manager.setPlastercount(1);
		 assertEquals(manager.getPlastercount(), 1);
	}
	
	@Test
	void testSetMedkitCountReturnsGetMedkitCount() {
		manager.setMedkitcount(1);
		 assertEquals(manager.getMedkitcount(), 1);
	}
	
	@Test
	void testSetBandageCountReturnsGetBandageCount() {
		manager.setBandagecount(1);
		 assertEquals(manager.getBandagecount(), 1);
	}
	
	@Test
	void testSetRiceCountReturnsGetRiceCount() {
		manager.setRicecount(1);
		 assertEquals(manager.getRicecount(), 1);
	}
	
	@Test
	void testSetRamenCountReturnsGetRamenCount() {
		manager.setRamencount(1);
		 assertEquals(manager.getRamencount(), 1);
	}
	
	@Test
	void testSetBrowniesCountReturnsGetBrowniesCount() {
		manager.setBrowniescount(1);
		 assertEquals(manager.getBrowniescount(), 1);
	}
	
	@Test
	void testSetHamburgerCountReturnsGetHamburgerCount() {
		manager.setHamburgercount(1);
		 assertEquals(manager.getHamburgercount(), 1);
	}
	
	
	@Test
	void testSetNutritionbarReturnsGetNutritionbarCount() {
		manager.setNutritionbarcount(1);
		 assertEquals(manager.getNutritionbarcount(), 1);
	}
	
	@Test
	void testSetChipsCountReturnsGetChipsCount() {
		manager.setChipscount(1);
		 assertEquals(manager.getChipscount(), 1);
	}
	
	@Test
	void testSetAdventureDaysReturnsGetAdventureDays() {
		manager.setAdventureDays(1);
		 assertEquals(manager.getAdventureDays(), 1);
	}
	
	@Test
	void testSetPiecesAmountReturnsGetPiecesAmount() {
		manager.setPiecesAmount(1);
		 assertEquals(manager.getPiecesAmount(), 1);
	}
	
	@Test
	void testSetCurrentDayReturnsGetCurrentDay() {
		manager.setCurrentDay(1);
		 assertEquals(manager.getCurrentDay(), 1);
	}
	
	@Test
	void testSetMoneyAmountReturnsGetCurrentMoney() {
		manager.setMoneyAmount(1);
		 assertEquals(manager.getCurrentMoney(), 1);
	}
	
	@Test
	void testSetCurrentPiecesReturnsGetCurrentPieces() {
		manager.setCurrentPieces(1);
		 assertEquals(manager.getCurrentPieces(), 1);
	}
	
	@Test
	void testSetCrewSizeReturnsGetCrewSize() {
		manager.setCrewSize(1);
		 assertEquals(manager.getCrewSize(), 1);
	}
	
	@Test
	void testSetCurrentMemberReturnsGetCurrentMember() {
		manager.setCurrentMember(1);
		 assertEquals(manager.getCurrentMember(), 1);
	}
	
	@Test
	void testSetCurrentScoreReturnsGetCurrentScore() {
		manager.setCurrentScore(1);
		 assertEquals(manager.getCurrentScore(), 1);
	}
	
	@Test
	void testSetShipNameReturnsGetShipName() {
		manager.setShipName("ship");
		 assertEquals(manager.getShipName(), "ship");
	}
	
	@Test
	void testSetShipShieldReturnsGetShipShield() {
		manager.setShipShield(10);
		 assertEquals(manager.getShipShield(), 10);
	}
	
	
}
