/**
 * Test cases for the Food class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Food;

class FoodTest {

	@Test
	void testConstructor() {
		Food food = new Food("rice");
        assertEquals(food.toString(), "rice");
	}
	
	@Test
	void testGetCost() {
		Food food1 = new Food("Rice");
		assertEquals(food1.getCost(), 50);
		Food food2 = new Food("Brownies");
		assertEquals(food2.getCost(), 20);
		Food food3 = new Food("Nutrition Bar");
		assertEquals(food3.getCost(), 30);
		Food food4 = new Food("Hamburger");
		assertEquals(food4.getCost(), 60);
		Food food5 = new Food("Chips");
		assertEquals(food5.getCost(), 10);
		Food food6 = new Food("Ramen");
		assertEquals(food6.getCost(), 40);
	}
}
