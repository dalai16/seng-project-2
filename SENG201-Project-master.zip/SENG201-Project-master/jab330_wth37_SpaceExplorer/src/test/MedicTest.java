/**
 * Test cases for the Medic class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Medic;

class MedicTest {

	@Test
	void testConstructor() {
		Medic medic = new Medic("jack");
        assertEquals(medic.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Medic medic = new Medic("jack");
		assertEquals(medic.toString(), "Medic");
	}
}
