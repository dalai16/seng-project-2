/**
 * Test cases for the Engineer class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Engineer;

class EngineerTest {

	@Test
	void testConstructor() {
		Engineer engineer = new Engineer("jack");
        assertEquals(engineer.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Engineer engineer = new Engineer("jack");
		assertEquals(engineer.toString(), "Engineer");
	}

}
