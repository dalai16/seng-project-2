/**
 * Test cases for the Captain class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Captain;

class CaptainTest {

	@Test
	void testConstructor() {
		Captain captain = new Captain("jack");
        assertEquals(captain.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Captain captain = new Captain("jack");
		assertEquals(captain.toString(), "Captain");
	}

}
