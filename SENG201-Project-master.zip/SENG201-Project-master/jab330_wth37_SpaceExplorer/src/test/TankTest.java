/**
 * Test cases for the Tank class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Tank;

class TankTest {

	@Test
	void testConstructor() {
		Tank tank = new Tank("jack");
        assertEquals(tank.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Tank tank = new Tank("jack");
		assertEquals(tank.toString(), "Tank");
	}
}
