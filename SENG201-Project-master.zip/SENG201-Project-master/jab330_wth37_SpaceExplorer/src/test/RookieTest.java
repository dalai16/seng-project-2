/**
 * Test cases for the Rookie class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Rookie;

class RookieTest {

	@Test
	void testConstructor() {
		Rookie rookie = new Rookie("jack");
        assertEquals(rookie.getName(), "jack");
	}
	
	@Test
	void testToString() {
		Rookie rookie = new Rookie("jack");
		assertEquals(rookie.toString(), "Rookie");
	}

}
