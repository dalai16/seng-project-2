/**
 * Test cases for the Inventory class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.Inventory;

class InventoryTest {

	@Test
	public void testSetPlaguecurecountGetPlaguecurecount() {
		Inventory inv = new Inventory();
		inv.setPlaguecurecount(1);
		assertEquals(inv.getPlaguecurecount(), 1);
	}
	
	@Test
	public void testSetPlastercountGetPlastercount() {
		Inventory inv = new Inventory();
		inv.setPlastercount(2);
		assertEquals(inv.getPlastercount(), 2);
	}
	
	@Test
	public void testSetMedkitcountGetMedkitcount() {
		Inventory inv = new Inventory();
		inv.setMedkitcount(3);
		assertEquals(inv.getMedkitcount(), 3);
	}
	
	@Test
	public void testSetBandagecountGetBandagecount() {
		Inventory inv = new Inventory();
		inv.setBandagecount(4);
		assertEquals(inv.getBandagecount(), 4);
	}
	
	
	@Test
	public void testSetRicecountGetRicecount() {
		Inventory inv = new Inventory();
		inv.setRicecount(4);
		assertEquals(inv.getRicecount(), 4);
	}
	
	@Test
	public void testSetRamencountGetRamencount() {
		Inventory inv = new Inventory();
		inv.setRamencount(5);
		assertEquals(inv.getRamencount(), 5);
	}
	
	@Test
	public void testSetBrowniescountGetBrowniescount() {
		Inventory inv = new Inventory();
		inv.setBrowniescount(6);
		assertEquals(inv.getBrowniescount(), 6);
	}
	
	@Test
	public void testSetHamburgercountGetHamburgercount() {
		Inventory inv = new Inventory();
		inv.setHamburgercount(7);
		assertEquals(inv.getHamburgercount(), 7);
	}
	
	@Test
	public void testSetNutritionbarcountGetNutritionbarcount() {
		Inventory inv = new Inventory();
		inv.setNutritionbarcount(8);
		assertEquals(inv.getNutritionbarcount(), 8);
	}
	
	@Test
	public void testSetChipscountGetChipscount() {
		Inventory inv = new Inventory();
		inv.setChipscount(9);
		assertEquals(inv.getChipscount(), 9);
	}

}
