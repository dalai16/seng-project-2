/**
 * Test cases for the CrewMembers class
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import main.CrewMembers;

class CrewMembersTest {
	
	@Test
	public void testconstructor() {
        CrewMembers team = new CrewMembers("jack", 5, 5, 100);
        assertEquals(team.getName(), "jack");
        assertEquals(team.getForaging(), 5);
        assertEquals(team.getRepairing(), 5);
        assertEquals(team.getHealth(), 100);
	}
	
	@Test
	public void testSetNameReturningGetName() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		 assertEquals(team.getName(), "jack");
		 team.setName("william");
		 assertEquals(team.getName(), "william");
	}
	
	@Test
	public void testSetHungerReturningGetHunger() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setHunger(-10);
		assertEquals(team.getHunger(), 0);
		team.setHunger(0);
		assertEquals(team.getHunger(), 0);
		team.setHunger(101);
		assertEquals(team.getHunger(), 100);
	}
	
	@Test
	public void testSetHealthReturningGetHealth() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setHealth(-100);
		assertEquals(team.getHealth(), 0);
		team.setHealth(100);
		assertEquals(team.getHealth(), 100);
		team.setHealth(200);
		assertEquals(team.getHealth(), 100);
	}
	
	@Test
	public void testSetTirednessReturningGetTiredness() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setTiredness(-50);
		assertEquals(team.getTiredness(), 0);
		team.setTiredness(49);
		assertEquals(team.getTiredness(), 49);
		team.setTiredness(1000);
		assertEquals(team.getTiredness(), 100);
	}
      
	@Test
	public void testSetActionPointsReturningGetActionPoints() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setActionPoints(-1);
		assertEquals(team.getActionPoints(), 0);
		team.setActionPoints(2);
		assertEquals(team.getActionPoints(), 2);
		team.setActionPoints(100);
		assertEquals(team.getActionPoints(), 2);
	}
	
	@Test
	public void testSetIsDiseasedReturningGetIsDiseased() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setDiseased(true);
		assertEquals(team.getDiseased(), true);
		team.setDiseased(false);
		assertEquals(team.getDiseased(), false);
	}
	
	@Test
	public void testSetDaysPlaguedReturningGetDaysPlagued() {
		CrewMembers team = new CrewMembers("jack", 5, 5, 100);
		team.setDaysPlagued(1);
		assertEquals(team.getDaysPlagued(), 1);
		team.setDaysPlagued(0);
		assertEquals(team.getDaysPlagued(), 0);
		team.setDaysPlagued(-1);
		assertEquals(team.getDaysPlagued(), 0);
	}

}
