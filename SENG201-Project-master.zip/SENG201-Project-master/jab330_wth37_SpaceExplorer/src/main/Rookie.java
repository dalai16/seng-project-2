/**
 * The Rookie class is an all rounded crew member type inherits the CrewMembers class.
 * it calls super with 3 foraging level and 3 repairing level and default 100 health.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Rookie extends CrewMembers {
	/**
	 * Rookie is an all rounded crew type with no specialisations or weaknesses
	 * calls to super with given name, 3 foraging, 3 repairing and 100 health.
	 * @param name  given name string
	 */
	public Rookie(String name) {
		super(name, 3, 3, 100);
	}
	
	/**
	 * string representation of rookie class
	 */
	public String toString() {
        return "Rookie";
    }
}