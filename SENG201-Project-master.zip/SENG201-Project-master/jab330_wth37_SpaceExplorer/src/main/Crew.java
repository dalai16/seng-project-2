/**
 * The crew class initializes the crew and adds functionality.
 * Within the crew class we hold ArrayList containing the
 * current crew members, medical items, and food items.
 * There is also getters and setters for setting and getting
 * the ship name, money amount, parts amount, and ship shield.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

import java.util.ArrayList;

public class Crew {
	/**
	 * The name of the ship
	 */
	private String shipName;
	/**
	 * The sum of the money
	 */
	private int moneyAmount = 0;
	/**
	 * The Transporter parts amount found
	 */
	private int partsAmount = 0;
	/**
	 * The Ship's shield amount
	 */
    private int shieldAmount = 100;
    /**
     * ArrayList which initializes the CrewMembers
     */
    private ArrayList<CrewMembers> teamMembers = new ArrayList<CrewMembers>();
    /**
     * ArrayList which initializes the Medical
     */
    private ArrayList<Medical> medicalItems = new ArrayList<Medical>();
    /**
     * ArrayList which initializes the FoodItems
     */
    private ArrayList<Food> foodItems = new ArrayList<Food>();

    /**
     * Returns an string of the selected shipName
     * @return The String of the shipName
     */
    public String getShipName() {
    	return shipName;
    }
    
    /**
     * Takes a string called name and sets shipName to the inputed string
     * @param name Sets the shipName equal to name
     */
    public void setShipName(String name) {
    	shipName = name;
    }
    
    /**
     * Returns an integer of money the crew currently has
     * @return The int of moneyAmount
     */
    public int getMoneyAmount() {
    	return moneyAmount;
    }
    
    /**
     * Takes an input of type integer called num and sets moneyAmount equal to num
     * @param num Sets the moneyAmount equal to num
     */
    public void setMoneyAmount(int num) {
    	moneyAmount = num;

    }
    
    /**
     * Returns an integer of parts the crew currently has
     * @return The int of partsAmount
     */
    public int getPartsAmount() {
    	return partsAmount;
    }
    
    /**
     * Takes an input of type int called num and sets partsAmount equal to num
     * @param num Sets the partsAmount equal to num
     */
    public void setPartsAmount(int num) {
    	partsAmount = num;
    }
    
    /**
     * Returns an integer of the current shield level
     * @return The int of shieldAmount
     */
    public int getShieldAmount() {
    	return shieldAmount;
    }
    
    /**
     * Takes an input of type integer called num and sets shieldAmount equal to num
     * @param num Sets the shieldAmount equal to num
     */
    public void setShieldAmount(int num) {
    	shieldAmount = num;
    }
    
    /**
     * Returns all CrewMembers within the ArrayList
     * @return The ArrayList of teamMembers
     */
    public ArrayList<CrewMembers> getCrewList() {
    	return teamMembers;
    }
    
    /**
     * Takes an input of type Object called object and adds to the teamMembers ArrayList
     * @param object Adds an Object of a crew member to the teamMembers ArrayList
     */
    public void addCrewMember(Object object) {
    	teamMembers.add((CrewMembers) object);
    }
    
    /**
     * Returns all Medical items within the ArrayList
     * @return The ArrayList of medicalItems
     */
    public ArrayList<Medical> getMedicalList() {
    	return medicalItems;
    }
    
    /**
     * Takes an input of type Object called object and adds to the medicalItems ArrayList
     * @param object Adds an Object of a medical item to the medicalItems ArrayList
     */
    public void addMedicalList(Medical object) {
    	medicalItems.add(object);
    }
    
    /**
     * Takes an input of type ArrayList of class Medical called list and sets medicalItems to list
     * @param list Sets medicalItems to the ArrayList called list
     */
    public void setMedicalList(ArrayList<Medical> list) {
    	medicalItems = list;
    }
    
    /**
     * Returns all Food items within the ArrayList
     * @return The ArrayList of foodItems
     */
    public ArrayList<Food> getFoodList() {
    	return foodItems;
    }
    
    /**
     * Takes an input of type Object called object and adds to the foodItems ArrayList
     * @param object Adds an Object of a food item to the foodItems ArrayList
     */
    public void addFoodList(Food object) {
    	foodItems.add(object);
    }
    
    /**
     * Takes an input of type ArrayList of class Food called list and sets foodItems to list
     * @param list Sets foodItems to the ArrayList called list
     */
    public void setFoodList(ArrayList<Food> list) {
    	foodItems = list;
    }  
}	
