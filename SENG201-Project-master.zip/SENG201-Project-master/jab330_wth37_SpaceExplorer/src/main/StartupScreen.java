/**
 * The StarupScreen class initializes amount of days the game will last, selected
 * by the player and shows the amount of transporter parts needed to find to win the game.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */
package main;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class StartupScreen {
	/**
	 * initialises JFrame and SpaceExplorerManager variables
	 * which allows calls from the main SpaceExplorerManager game environment
	 * and window methods to be used. 
	 */
	private JFrame frame;
	private SpaceExplorerManager manager;
	/**
	 * StartupScreen constructor takes
	 * @param incomingManager  .The main game manager that
	 * allows for access to key methods and variables throughout the game,
	 * including launching the screen.
	 */
	public StartupScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	/**
	 * method to close the StartupScreen
	 */
	public void closeWindow() {
		frame.dispose();
	}
	
	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartupScreen window = new StartupScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StartupScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Beginning Your Adventure");
		frame.setBounds(100, 100, 480, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * label displaying text "How long will your adventure last?"
		 */
		JLabel lblNumberOfDays = new JLabel("How long will your adventure last?");
		lblNumberOfDays.setBounds(10, 10, 240, 35);
		frame.getContentPane().add(lblNumberOfDays);
		
		/**
		 * label displaying text "Spaceship pieces required to find:"
		 */
		JLabel lblSpaceshipPieces = new JLabel("Spaceship pieces required to find:");
		lblSpaceshipPieces.setBounds(10, 70, 200, 35);
		frame.getContentPane().add(lblSpaceshipPieces);
		
		/**
		 * closes startup screen window and calls a launch to
		 * crew creation screen from the SpaceExplorerManager manager 
		 * when the button is clicked.
		 */
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeWindow();
				manager.launchCrewCreationScreen();
			}
		});
		btnNext.setBounds(351, 125, 89, 23);
		frame.getContentPane().add(btnNext);
		
		/**
		 * shows the current amount of transporter pieces the player is
		 * required to find to win the game. this is correlated to the 
		 * number of days the player chooses. while day selection changes, 
		 * updates number of playing days and required transporter pieces 
		 */
		JLabel lblNumberOfPieces = new JLabel("2");
		lblNumberOfPieces.setBounds(220, 76, 34, 23);
		frame.getContentPane().add(lblNumberOfPieces);
		JSlider slider = new JSlider();
		slider.setValue(2);
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSlider slider = (JSlider) e.getSource();
		        if (!slider.getValueIsAdjusting()) {
		        	manager.setAdventureDays(slider.getValue());
		        	manager.setPiecesAmount(manager.getAdventureDays() * 2 / 3);
		        	lblNumberOfPieces.setText(String.valueOf(manager.getPiecesAmount()));
		        }
		    }
		});
		slider.setToolTipText("");
		slider.setSnapToTicks(true);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMinorTickSpacing(1);
		slider.setMajorTickSpacing(1);
		slider.setMinimum(3);
		slider.setMaximum(10);
		slider.setBounds(220, 10, 220, 45);
		frame.getContentPane().add(slider);
		
		/**
		 * button that allows player to quit the game
		 * when it is clicked. asks player to confirm action.
		 */
		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmed = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to exit the program?", "Exit Program Message Box", 
						JOptionPane.YES_NO_OPTION);
				if (confirmed == JOptionPane.YES_OPTION) {
					closeWindow();
				}
			}
		});
		btnQuit.setBounds(10, 125, 89, 23);
		frame.getContentPane().add(btnQuit);
	}
}
