/**
 * InventoryScreen is a graphical interface.
 * Within the inventory screen the user is able to
 * see their current items they hold and they are able
 * to use those items on their crew members.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;

 
public class InventoryScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	
	/**
	 * InventoryScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public InventoryScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	
	/**
	 * closeWindow disposes the current frame in use
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InventoryScreen window = new InventoryScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	/**
	 * Create the application.
	 */
	public InventoryScreen() {
		initialize();
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Inventory");
		frame.setBounds(100, 100, 400, 357);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * JLabel that displays text Inventory
		 */
		JLabel lblInventory = new JLabel("Inventory");
		lblInventory.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblInventory.setBounds(10, 13, 85, 28);
		frame.getContentPane().add(lblInventory);
		
		/**
		 * JLabel that shows the crews current amount of money
		 */
		JLabel lblMoney = new JLabel("Money: $\r\n" + manager.getCrew().getMoneyAmount());
		lblMoney.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblMoney.setBounds(132, 11, 85, 32);
		frame.getContentPane().add(lblMoney);
		
		/**
		 * Initialize the crews inventory
		 */
		JList<String> listInventory = new JList<String>();
		listInventory.setFont(new Font("Tahoma", Font.PLAIN, 14));
		listInventory.setModel(new AbstractListModel<String>() {
			private static final long serialVersionUID = 1L;
			String[] values = new String[] {"Plague Cure", "Plaster", "Bandage", "Medkit", "Nutrition Bar", "Rice", "Chips", "Hamburger", "Ramen", "Brownies"};
			public int getSize() {
				return values.length;
			}
			public String getElementAt(int index) {
				return values[index];
			}
		});
		listInventory.setBounds(37, 65, 85, 204);
		frame.getContentPane().add(listInventory);
		
		/**
		 * JLabel displaying Item Quantities 
		 */
		JLabel lblQuantities = new JLabel("<html>" + manager.getPlaguecurecount() + "<br/>"
				+ manager.getPlastercount() + "<br/>" + manager.getBandagecount() + "<br/>" + manager.getMedkitcount() + "<br/>"
				+ manager.getNutritionbarcount() + "<br/>" + manager.getRicecount() + "<br/>" + manager.getChipscount() + "<br/>"
				+ manager.getHamburgercount() + "<br/>" + manager.getRamencount() + "<br/>" + manager.getBrowniescount() + "\r\n</html>");
		lblQuantities.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblQuantities.setBounds(132, 58, 74, 205);
		frame.getContentPane().add(lblQuantities);
		
		/**
		 * JButton to go back to the game screen
		 */
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				closeWindow();
				manager.launchGameScreen();
			}
		});
		btnBack.setBounds(10, 281, 85, 32);
		frame.getContentPane().add(btnBack);
		
		
		/**
		 * JRadioButton used to select the crew member to use an item on
		 * and enables the button when clicked
		 */
		JRadioButton rdbtnPlayer1 = new JRadioButton(manager.getCrewName(0));
		rdbtnPlayer1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnPlayer1.setBounds(212, 122, 109, 23);
		frame.getContentPane().add(rdbtnPlayer1);
		if (manager.getCrewHealth(0) <= 0) {
			rdbtnPlayer1.setEnabled(false);
		}
		
		/**
		 * JRadioButton used to select the crew member to use an item on
		 * and enables the button when clicked
		 */
		JRadioButton rdbtnPlayer2 = new JRadioButton(manager.getCrewName(1));
		rdbtnPlayer2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnPlayer2.setBounds(212, 148, 109, 23);
		frame.getContentPane().add(rdbtnPlayer2);
		if (manager.getCrewHealth(1) <= 0) {
			rdbtnPlayer2.setEnabled(false);
		}
		
		/**
		 * JRadioButton used to select the crew member to use an item on
		 * and enables the button when clicked 
		 */
		JRadioButton rdbtnPlayer3 = new JRadioButton();
		rdbtnPlayer3.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnPlayer3.setBounds(212, 174, 109, 23);
		frame.getContentPane().add(rdbtnPlayer3);
		if (manager.getCrewSize() == 2) {
			rdbtnPlayer3.setVisible(false);
		}
		else {
			rdbtnPlayer3.setText(manager.getCrewName(2));
			if (manager.getCrewHealth(2) <= 0) {
			rdbtnPlayer3.setEnabled(false);
			}
		}
		
		/**
		 * JRadioButton used to select the crew member to use an item on
		 * and enables the button when clicked
		 */
		JRadioButton rdbtnPlayer4 = new JRadioButton();
		rdbtnPlayer4.setFont(new Font("Tahoma", Font.PLAIN, 12));
		rdbtnPlayer4.setBounds(212, 200, 109, 23);
		frame.getContentPane().add(rdbtnPlayer4);
		if (manager.getCrewSize() == 2) {
			rdbtnPlayer4.setVisible(false);
		}
		else if (manager.getCrewSize() == 3) {
			rdbtnPlayer4.setVisible(false);
			rdbtnPlayer3.setText(manager.getCrewName(2));
		}
		
		else {
			rdbtnPlayer3.setText(manager.getCrewName(2));
			rdbtnPlayer4.setText(manager.getCrewName(3));
			if (manager.getCrewHealth(3) <= 0) {
				rdbtnPlayer4.setEnabled(false);
			}
		}
		
		/*
		 * JButton for when an item is used on a crew member
		 * if statements to ensure the item exists and can be used
		 * if statements to ensure the player is alive and has
		 * less than 100 hunger or health depending on item used
		 * pop ups to display if errors occurred
		 * also updates JLabels to display quantities
		 */
		JButton btnUseitem = new JButton("Use Item");
		btnUseitem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String item = listInventory.getSelectedValue();
				boolean selected = true;
				CrewMembers member = manager.getCrew().getCrewList().get(1);
				if (item == null) {
					JOptionPane.showMessageDialog(null, "Pick an item to use");
				}
				if (rdbtnPlayer1.isSelected()) { 
					member = manager.getCrew().getCrewList().get(0);
				}
				else if (rdbtnPlayer2.isSelected()) {
					member = manager.getCrew().getCrewList().get(1);
				}
				else if (rdbtnPlayer3.isSelected()) {
					member = manager.getCrew().getCrewList().get(2);
				}
				else if (rdbtnPlayer4.isSelected()) {
					member = manager.getCrew().getCrewList().get(3);
				}
				
				else {
					selected = false;
					JOptionPane.showMessageDialog(null, "Please select a Crew member");
				}
				if (selected) {
					if (item == "Plague Cure") {
						if (manager.getPlaguecurecount() != 0) {
							if (member.getDiseased()) {
							member.setDiseased(false);
							manager.setPlaguecurecount(manager.getPlaguecurecount() - 1);
							JOptionPane.showMessageDialog(null, "Crew member cured of Space Plague");
							for(Medical medical: manager.getCrew().getMedicalList()) {
								if (medical.toString() == "Plague Cure") {
									manager.getCrew().getMedicalList().remove(medical);
									break;
								}
							}
							}
							else {
								JOptionPane.showMessageDialog(null, "Crew member does not have space plague");
							}
					}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
					}
					else if (item == "Bandage") {
						Medical meds = new Medical("Bandage");
						if (manager.getBandagecount() != 0) {
							if (member.getHealth() < 100) {
							JOptionPane.showMessageDialog(null, "Crew member restored health with Bandage");
							manager.setBandagecount(manager.getBandagecount() - 1);
							member.setHealth(meds.getCost() + member.getHealth());
							for(Medical medical: manager.getCrew().getMedicalList()) {
								if (medical.toString() == "Bandage") {
									manager.getCrew().getMedicalList().remove(medical);
									break;
								}
								}
							}
							else {
								JOptionPane.showMessageDialog(null, "Crew member is already full health");
							}
							}
						else {
							JOptionPane.showMessageDialog(null, "You do not own this item!");
						}
					}
					
					else if (item == "Medkit") {
					Medical meds = new Medical("Medkit");
					if (manager.getMedkitcount() != 0) {
						if (member.getHealth() < 100) {
						manager.setMedkitcount(manager.getMedkitcount() - 1);
						member.setHealth(meds.getCost() + member.getHealth());
						JOptionPane.showMessageDialog(null, "Crew member restored health with Medkit");
						for(Medical medical: manager.getCrew().getMedicalList()) {
							if (medical.toString() == "Medkit") {
								manager.getCrew().getMedicalList().remove(medical);
								break;
							}
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full health");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
					else if (item == "Plaster") {
					Medical meds = new Medical("Plaster");
					if (manager.getPlastercount() != 0) {
						if (member.getHealth() < 100) {
						manager.setPlastercount(manager.getPlastercount() - 1);
						JOptionPane.showMessageDialog(null, "Crew member restored health with Plaster");
						member.setHealth(meds.getCost() + member.getHealth());
						for(Medical medical: manager.getCrew().getMedicalList()) {
							if (medical.toString() == "Plaster") {
								manager.getCrew().getMedicalList().remove(medical);
								break;
							}
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full health");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Brownies") {
					Food food = new Food("Brownies");
					if (manager.getBrowniescount() != 0) {
						if (member.getHunger() < 100) {
						manager.setBrowniescount(manager.getBrowniescount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Brownies") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Rice") {
					Food food = new Food("Rice");
					if (manager.getRicecount() != 0) {
						if (member.getHunger() < 100) {
						JOptionPane.showMessageDialog(null, "Crew member retored health by eating Rice");
						manager.setRicecount(manager.getRicecount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Rice") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
							}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Ramen") {
					Food food = new Food("Ramen");
					if (manager.getRamencount() != 0) {
						if (member.getHunger() < 100) {
						JOptionPane.showMessageDialog(null, "Crew member retored health by eating Ramen");
						manager.setRamencount(manager.getRamencount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Ramen") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
						}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Nutrition Bar") {
					Food food = new Food("Nutrition Bar");
					if (manager.getNutritionbarcount() != 0) {
						if (member.getHunger() < 100) {
						JOptionPane.showMessageDialog(null, "Crew member retored health by eating Nutrition Bar");
						manager.setNutritionbarcount(manager.getNutritionbarcount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Nutrition Bar") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
						}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Hamburger") {
					Food food = new Food("Hamburger");
					if (manager.getHamburgercount() != 0) {
						if (member.getHunger() < 100) {
						JOptionPane.showMessageDialog(null, "Crew member retored health by eating Hamburger");
						manager.setHamburgercount(manager.getHamburgercount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Hamburger") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
						}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				else if (item == "Chips") {
					Food food = new Food("Chips");
					if (manager.getChipscount() != 0) {
						if (member.getHunger() < 100) {
						JOptionPane.showMessageDialog(null, "Crew member retored health by eating Chips");
						manager.setChipscount(manager.getChipscount() - 1);
						member.setHunger(food.getCost() + member.getHunger());
						for(Food item_food: manager.getCrew().getFoodList()) {
							if (item_food.toString() == "Chips") {
								manager.getCrew().getFoodList().remove(item_food);
								break;
							}
						}
						}
						else {
							JOptionPane.showMessageDialog(null, "Crew member is already full hunger");
						}
						}
					else {
						JOptionPane.showMessageDialog(null, "You do not own this item!");
					}
				}
				}
			lblQuantities.setText("<html>" + manager.getPlaguecurecount() + "<br/>"
						+ manager.getPlastercount() + "<br/>" + manager.getBandagecount() + "<br/>" + manager.getMedkitcount() + "<br/>"
						+ manager.getNutritionbarcount() + "<br/>" + manager.getRicecount() + "<br/>" + manager.getChipscount() + "<br/>"
						+ manager.getHamburgercount() + "<br/>" + manager.getRamencount() + "<br/>" + manager.getBrowniescount() + "\r\n</html>");
			}
		});
		btnUseitem.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnUseitem.setBounds(168, 244, 92, 52);
		frame.getContentPane().add(btnUseitem);
		
		/**
		 * Radio button listener to check set not selected options to false
		 */
		rdbtnPlayer1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnPlayer2.setSelected(false);
				rdbtnPlayer3.setSelected(false);
				rdbtnPlayer4.setSelected(false);
			}
		});
		
		/**
		 * Radio button listener to check set not selected options to false
		 */
		rdbtnPlayer2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnPlayer1.setSelected(false);
				rdbtnPlayer3.setSelected(false);
				rdbtnPlayer4.setSelected(false);

			}
		});
		
		/**
		 * Radio button listener to check set not selected options to false
		 */
		rdbtnPlayer3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnPlayer1.setSelected(false);
				rdbtnPlayer2.setSelected(false);
				rdbtnPlayer4.setSelected(false);
			}
		});
		
		/**
		 * Radio button listener to check set not selected options to false
		 */
		rdbtnPlayer4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtnPlayer1.setSelected(false);
				rdbtnPlayer2.setSelected(false);
				rdbtnPlayer3.setSelected(false);
			}
		});
		
		/**
		 * JLabel to show the amount of parts obtained currently
		 */
		JLabel lblPartsfound = new JLabel("Parts Found: " + manager.getCurrentPieces() + "/" + manager.getPiecesAmount());
		lblPartsfound.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPartsfound.setBounds(237, 13, 119, 29);
		frame.getContentPane().add(lblPartsfound);
		
		/*
		 * JLabel to display text for selection
		 */
		JLabel lblCrewSelect = new JLabel("<html>Select Crewmember <br/>To Use Item On</html>");
		lblCrewSelect.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblCrewSelect.setBounds(212, 63, 119, 52);
		frame.getContentPane().add(lblCrewSelect);
		
	}
}
