/**
 * CrewCreationScreen is a graphical interface.
 * Within CrewCreationScreen a user is able to
 * choose their spaceship name, how many crew members,
 * and their crew member name and class. The user can
 * also use buttons which display class descriptions and
 * buttons to quit, back, and start adventure.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Component;
import javax.swing.JTextField;
import javax.swing.JSlider;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Font;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;

public class CrewCreationScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * The name of the ship
	 */
	private JTextField spaceshipName;
	/**
	 * The name of crew member 1
	 */
	private JTextField crewName1;
	/**
	 * The name of crew member 2
	 */
	private JTextField crewName2;
	/**
	 * The name of crew member 3
	 */
	private JTextField crewName3;
	/**
	 * The name of crew member 4
	 */
	private JTextField crewName4;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	/**
	 * Integer for max string input length
	 */
	private int maxAmount = 12;

	/**
	 * CrewCreationScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public CrewCreationScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	
	/**
	 * closeWindow disposes the current frame in use
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrewCreationScreen window = new CrewCreationScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CrewCreationScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Selecting Your Crew Memebers");
		frame.setBounds(100, 100, 580, 380);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * Creates a JLabel displaying the information of the current
		 *  class selected which defaults to rookie.
		 */
		JLabel classSummary = new JLabel("<html> Class description: <br><br/> Rookie is an all-rounded crew type with no specialisations or weaknesses </html>");
		classSummary.setBounds(440, 85, 120, 121);
		frame.getContentPane().add(classSummary);
		
		/**
		 * Creates a JLabel displaying the information of the current
		 * class selected which defaults to rookie.
		 */
		JLabel crewStats = new JLabel("<html> Class Type: Rookie <br/><br/> Foraging: 3 <br/><br/> Repairing: 3<br/> </html>");
		crewStats.setBounds(307, 84, 125, 91);
		frame.getContentPane().add(crewStats);

		/**
		 * JLabel displaying Spaceship Name:
		 */
		JLabel crewcreationtitle = new JLabel("Spaceship Name:");
		crewcreationtitle.setFont(new Font("Tahoma", Font.PLAIN, 12));
		crewcreationtitle.setBounds(10, 10, 100, 30);
		frame.getContentPane().add(crewcreationtitle);
		
		/**
		 * JLabel displaying Number of Crew Members:
		 */
		JLabel lblNumCrew = new JLabel("Number of Crew Members:");
		lblNumCrew.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNumCrew.setBounds(10, 45, 150, 30);
		lblNumCrew.setAlignmentX(Component.CENTER_ALIGNMENT);
		frame.getContentPane().add(lblNumCrew);
		
		/**
		 * JTextField which a user can add their desired spaceship name
		 * This textfield will deafult to Spaceship
		 */
		spaceshipName = new JTextField();
		spaceshipName.setText("Spaceship");
		spaceshipName.setBounds(185, 16, 220, 20);
		frame.getContentPane().add(spaceshipName);
		spaceshipName.setColumns(10);
		
		/**
		 * JLabel displaying Player Names:
		 */
		JLabel lblCrewNames = new JLabel("Player Names:");
		lblCrewNames.setBounds(10, 211, 100, 30);
		frame.getContentPane().add(lblCrewNames);
		
		/**
		 * JTextField which a user can add their desired player name
		 * This textfield will default to Player 1
		 */
		crewName1 = new JTextField();
		crewName1.setToolTipText("");
		crewName1.setText("Player 1");
		crewName1.setBounds(120, 217, 80, 20);
		frame.getContentPane().add(crewName1);
		crewName1.setColumns(10);
		
		/**
		 * JTextField which a user can add their desired player name
		 * This textfield will default to Player 2
		 */
		crewName2 = new JTextField();
		crewName2.setText("Player 2");
		crewName2.setBounds(220, 217, 80, 20);
		frame.getContentPane().add(crewName2);
		crewName2.setColumns(10);
		
		/**
		 * JTextField which a user can add their desired player name
		 * This textfield will default to Player 3
		 */
		crewName3 = new JTextField();
		crewName3.setText("Player 3");
		crewName3.setBounds(320, 217, 80, 20);
		frame.getContentPane().add(crewName3);
		crewName3.setColumns(10);
		
		/**
		 * JTextField which a user can add their desired player name
		 * This textfield will default to Player 4
		 */
		crewName4 = new JTextField();
		crewName4.setText("Player 4");
		crewName4.setBounds(420, 217, 80, 20);
		frame.getContentPane().add(crewName4);
		crewName4.setColumns(10);
		
		/**
		 * Initialize the CrewMembers class within the JComboBox
		 * The player can select a certain class they want to play as
		 */
		CrewMembers rookie_p1 = new Rookie(crewName1.getText());
		CrewMembers tank_p1 = new Tank(crewName1.getText());
		CrewMembers medic_p1 = new Medic(crewName1.getText());
		CrewMembers scout_p1 = new Scout(crewName1.getText());
		CrewMembers engineer_p1 = new Engineer(crewName1.getText());
		CrewMembers captain_p1 = new Captain(crewName1.getText());
		JComboBox<CrewMembers> comboBox_Crew1 = new JComboBox<CrewMembers>();
		comboBox_Crew1.setModel((ComboBoxModel<CrewMembers>) new DefaultComboBoxModel<CrewMembers>(new CrewMembers[] {rookie_p1, tank_p1, medic_p1, scout_p1, engineer_p1, captain_p1}));
		comboBox_Crew1.setBounds(122, 248, 80, 20);
		frame.getContentPane().add(comboBox_Crew1);

		/**
		 * Initialize the CrewMembers class within the JComboBox
		 * The player can select a certain class they want to play as
		 */
		CrewMembers rookie_p2 = new Rookie(crewName2.getText());
		CrewMembers tank_p2 = new Tank(crewName2.getText());
		CrewMembers medic_p2 = new Medic(crewName2.getText());
		CrewMembers scout_p2 = new Scout(crewName2.getText());
		CrewMembers engineer_p2 = new Engineer(crewName2.getText());
		CrewMembers captain_p2 = new Captain(crewName2.getText());
		JComboBox<CrewMembers> comboBox_Crew2 = new JComboBox<CrewMembers>();
		comboBox_Crew2.setModel((ComboBoxModel<CrewMembers>) new DefaultComboBoxModel<CrewMembers>(new CrewMembers[] {rookie_p2, tank_p2, medic_p2, scout_p2, engineer_p2, captain_p2}));
		comboBox_Crew2.setBounds(220, 248, 80, 20);
		frame.getContentPane().add(comboBox_Crew2);

		/**
		 * Initialize the CrewMembers class within the JComboBox
		 * The player can select a certain class they want to play as
		 */
		CrewMembers rookie_p3 = new Rookie(crewName3.getText());
		CrewMembers tank_p3 = new Tank(crewName3.getText());
		CrewMembers medic_p3 = new Medic(crewName3.getText());
		CrewMembers scout_p3 = new Scout(crewName3.getText());
		CrewMembers engineer_p3 = new Engineer(crewName3.getText());
		CrewMembers captain_p3 = new Captain(crewName3.getName());
		JComboBox<CrewMembers> comboBox_Crew3 = new JComboBox<CrewMembers>();
		comboBox_Crew3.setModel((ComboBoxModel<CrewMembers>) new DefaultComboBoxModel<CrewMembers>(new CrewMembers[] {rookie_p3, tank_p3, medic_p3, scout_p3, engineer_p3, captain_p3}));
		comboBox_Crew3.setBounds(320, 248, 80, 20);
		frame.getContentPane().add(comboBox_Crew3);

		/**
		 * Initialize the CrewMembers class within the JComboBox
		 * The player can select a certain class they want to play as
		 */
		CrewMembers rookie_p4 = new Rookie(crewName4.getText());
		CrewMembers tank_p4 = new Tank(crewName4.getText());
		CrewMembers medic_p4 = new Medic(crewName4.getText());
		CrewMembers scout_p4 = new Scout(crewName4.getText());
		CrewMembers engineer_p4 = new Engineer(crewName4.getText());
		CrewMembers captain_p4 = new Captain(crewName4.getText());
		JComboBox<CrewMembers> comboBox_Crew4 = new JComboBox<CrewMembers>();
		comboBox_Crew4.setModel((ComboBoxModel<CrewMembers>) new DefaultComboBoxModel<CrewMembers>(new CrewMembers[] {rookie_p4, tank_p4, medic_p4, scout_p4, engineer_p4, captain_p4}));
		comboBox_Crew4.setBounds(420, 248, 80, 20);
		frame.getContentPane().add(comboBox_Crew4);
		
		/**
		 * JSlider which the player can use to select how many crew
		 * members in which they want to play with
		 * Contains if statements to hide/show options in which too
		 * little or more crew members are chosen
		 */
		JSlider crewslider = new JSlider();
		crewslider.setValue(2);
		crewslider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				JSlider crewslider = (JSlider) e.getSource();
		        if (!crewslider.getValueIsAdjusting()) {
		        	manager.setCrewSize(crewslider.getValue());
		        	if (manager.getCrewSize() == 2) {
		        		crewName3.setVisible(false);
		        		crewName4.setVisible(false);
		        		comboBox_Crew3.setVisible(false);
		        		comboBox_Crew4.setVisible(false);
		        	}
		        	else if (manager.getCrewSize() == 3) {
		        		crewName3.setVisible(true);
		        		crewName4.setVisible(false);
		        		comboBox_Crew3.setVisible(true);
		        		comboBox_Crew4.setVisible(false);
		        	}
		        	else {
		        		crewName3.setVisible(true);
		        		crewName4.setVisible(true);
		        		comboBox_Crew3.setVisible(true);
		        		comboBox_Crew4.setVisible(true);
		        	}
		        }
		    }
		});
		crewslider.setSnapToTicks(true);
		crewslider.setPaintLabels(true);
		crewslider.setMinorTickSpacing(1);
		crewslider.setMajorTickSpacing(1);
		crewslider.setMinimum(2);
		crewslider.setMaximum(4);
		crewslider.setBounds(186, 45, 200, 35);
		frame.getContentPane().add(crewslider);
		
		/**
		 * JLabel displaying Class Selection
		 */
		JLabel lblClassSelect = new JLabel("Class Selection:");
		lblClassSelect.setBounds(10, 241, 120, 30);
		frame.getContentPane().add(lblClassSelect);
		
		/**
		 * JButton for tank in which when pressed the crewStats
		 * and classSummary text are updated to display tanks information
		 */
		JButton btnTank;
		btnTank = new JButton("Tank");
		btnTank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Tank <br/><br/> Foraging: 2 <br/><br/> Repairing: 2<br/> </html>");
				classSummary.setText("<html> Class description: <br><br/> Tank is weak at foraging and repairing but has increased health </html>");
			}
		});
		btnTank.setBounds(113, 86, 89, 54);
		frame.getContentPane().add(btnTank);
		
		/**
		 * JButton for medic in which when pressed the crewStats
		 * and classSummary text are updated to display medics information
		 */
		JButton btnMedic;
		btnMedic = new JButton("Medic");
		btnMedic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Medic <br/><br/> Foraging: 2 <br/><br/> Repairing: 2 <br/> </html>");
				classSummary.setText("<html> Class description: <br><br/> Medic has poor foraging and repairing skills but starts the game with a random medical item </html>");

			}
		});
		btnMedic.setBounds(215, 86, 82, 55);
		frame.getContentPane().add(btnMedic);
		
		/**
		 * JButton for scout in which when pressed the crewStats
		 * and classSummary text are updated to display scouts information
		 */
		JButton btnScout;
		btnScout = new JButton("Scout");
		btnScout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Scout <br/><br/> Foraging: 5 <br/><br/> Repairing: 1<br/> </html>");
				classSummary.setText("<html> Class description: <br><br/> Scout is a master at finding tansporter parts but lacks skill in repairing </html>");
			}
		});
		btnScout.setBounds(10, 150, 89, 54);
		frame.getContentPane().add(btnScout);
		
		/**
		 * JButton for engineer in which when pressed the crewStats
		 * and classSummary text are updated to display engineers information
		 */
		JButton btnEngineer;
		btnEngineer = new JButton("Engineer");
		btnEngineer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Engineer <br/><br/> Foraging: 1 <br/><br/> Repairing: 5<br/> </html>");
				classSummary.setText("<html> Class description: <br><br/> Engineer is skilled at repairing the ship's shield but is a novice forager </html>");

			}
		});
		btnEngineer.setBounds(113, 151, 89, 54);
		frame.getContentPane().add(btnEngineer);
		
		/**
		 * JButton for captain in which when pressed the crewStats
		 * and classSummary text are updated to display captains information
		 */
		JButton btnCaptain;
		btnCaptain = new JButton("Captain");
		btnCaptain.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Captain <br/><br/> Foraging: 4 <br/><br/> Repairing: 4<br/> </html>");
				classSummary.setText("<html> Class description: <br><br/> Captain is strong at foraging and repairing but his energy levels deplete quicker </html>");
			}
		});
		btnCaptain.setBounds(215, 150, 82, 54);
		frame.getContentPane().add(btnCaptain);
		
		/**
		 * JButton for rookie in which when pressed the crewStats
		 * and classSummary text are updated to display rookies information
		 */
		JButton btnRookie = new JButton("Rookie");
		btnRookie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				crewStats.setText("<html> Class Type: Rookie <br><br> Foraging: 3 <br><br> Repairing: 3<br> </html>");
				classSummary.setText("<html> Class description: <br><br> Rookie is an all-rounded crew type with no specialisations or weaknesses </html>");
			}
		});
		btnRookie.setBounds(10, 85, 89, 54);
		frame.getContentPane().add(btnRookie);
		
		/**
		 * JButton to start the game
		 * when the button is clicked it checks if any of the
		 * text fields do not meet the character length restrictions
		 * It also checks how many crew members will be used and adds
		 * them to the ArrayList
		 * Also if a medic class is chosen a random medical item is
		 * added to the crews inventory
		 * Finally the screen is closed and the GameScreen is opened
		 */
		JButton btnStartAdventure = new JButton("Start Adventure");
		btnStartAdventure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				comboBox_Crew2.getSelectedItem();
				manager.setCrewSize(crewslider.getValue());
				manager.setShipName(spaceshipName.getText());
				if(manager.getShipName().equals("")) {
					JOptionPane.showMessageDialog(null, "Please enter a Spaceship name.");
				}
				else if(manager.getShipName().length() > maxAmount) {
					JOptionPane.showMessageDialog(null, "Spaceship name can't be longer than " + maxAmount + " characters.");
				}
				else if(crewName1.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please enter a name for Player 1.");
				}
				else if(crewName1.getText().length() > maxAmount) {
					JOptionPane.showMessageDialog(null, "Player 1's name can't be longer than " + maxAmount + " characters.");
				}
				else if(crewName2.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please enter a name for Player 2.");
				}
				else if(crewName2.getText().length() > maxAmount) {
					JOptionPane.showMessageDialog(null, "Player 2's name can't be longer than " + maxAmount + " characters.");
				}
				else if(crewName3.getText().equals("") && manager.getCrewSize() == 3) {
					JOptionPane.showMessageDialog(null, "Please enter a name for Player 3.");
				}
				else if(crewName3.getText().length() > maxAmount && manager.getCrewSize() == 3) {
					JOptionPane.showMessageDialog(null, "Player 3's name can't be longer than " + maxAmount + " characters.");
				}
				else if(crewName4.getText().equals("") && manager.getCrewSize() == 4) {
					JOptionPane.showMessageDialog(null, "Please enter a name for Player 4.");
				}
				else if(crewName4.getText().length() > maxAmount && manager.getCrewSize() == 4) {
					JOptionPane.showMessageDialog(null, "Player 4's name can't be longer than " + maxAmount + " characters.");
				}
				else {
					manager.addCrewMember(comboBox_Crew1.getSelectedItem());
					rookie_p1.setName(crewName1.getText());
					tank_p1.setName(crewName1.getText());
					medic_p1.setName(crewName1.getText());
					scout_p1.setName(crewName1.getText());
					engineer_p1.setName(crewName1.getText());
					captain_p1.setName(crewName1.getText());
					manager.addCrewMember(comboBox_Crew2.getSelectedItem());
					rookie_p2.setName(crewName2.getText());
					tank_p2.setName(crewName2.getText());
					medic_p2.setName(crewName2.getText());
					scout_p2.setName(crewName2.getText());
					engineer_p2.setName(crewName2.getText());
					captain_p2.setName(crewName2.getText());
					if(manager.getCrewSize() >= 3) {
						manager.addCrewMember(comboBox_Crew3.getSelectedItem());
						rookie_p3.setName(crewName3.getText());
						tank_p3.setName(crewName3.getText());
						medic_p3.setName(crewName3.getText());
						scout_p3.setName(crewName3.getText());
						engineer_p3.setName(crewName3.getText());
						captain_p3.setName(crewName3.getText());
					}
					if(manager.getCrewSize() >= 4) {
						manager.addCrewMember(comboBox_Crew4.getSelectedItem());
						rookie_p4.setName(crewName4.getText());
						tank_p4.setName(crewName4.getText());
						medic_p4.setName(crewName4.getText());
						scout_p4.setName(crewName4.getText());
						engineer_p4.setName(crewName4.getText());
						captain_p4.setName(crewName4.getText());
					}
					for (CrewMembers member: manager.getCrew().getCrewList()) {
						if(member.toString() == "Medic") {
							Random random = new Random();
							switch(random.nextInt(4)+1) {
							case 1:
								Medical plague = new Medical("Plague Cure");
								manager.getCrew().addMedicalList(plague);
								manager.setPlaguecurecount(manager.getPlaguecurecount() + 1);
								JOptionPane.showMessageDialog(null, member.getName() + " gave the crew a Plague Cure");
								break;
							case 2:
								Medical medkit = new Medical("Medkit");
								manager.getCrew().addMedicalList(medkit);
								manager.setMedkitcount(manager.getMedkitcount() + 1);
								JOptionPane.showMessageDialog(null, member.getName() + " gave the crew a Medkit");
								break;
							case 3:
								Medical bandage = new Medical("Bandage");
								manager.getCrew().addMedicalList(bandage);
								manager.setBandagecount(manager.getBandagecount() + 1);
								JOptionPane.showMessageDialog(null, member.getName() + " gave the crew a Bandage");
								break;
							case 4:
								Medical plaster = new Medical("Plaster");
								manager.getCrew().addMedicalList(plaster);
								manager.setPlastercount(manager.getPlastercount() + 1);
								JOptionPane.showMessageDialog(null, member.getName() + " gave the crew a Plaster");
								break;
						}
					}
					}
					closeWindow();
					manager.launchGameScreen();
				}
			}
		});
		btnStartAdventure.setBounds(424, 299, 130, 30);
		frame.getContentPane().add(btnStartAdventure);
		
		/**
		 * JButton to go back to SetupScreen
		 */
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeWindow();
				manager.launchStartupScreen();
			}
		});
		btnBack.setBounds(221, 299, 120, 30);
		frame.getContentPane().add(btnBack);
		
		/**
		 * JButton that allows player to quit the game when it is clicked
		 * Also asks player to confirm action
		 */
		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int confirmed = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to exit the program?", "Exit Program Message Box",
						JOptionPane.YES_NO_OPTION);
				if (confirmed == JOptionPane.YES_OPTION) {
					closeWindow();
				}
			}
		});
		btnQuit.setBounds(10, 299, 120, 30);
		frame.getContentPane().add(btnQuit);
	}
}
