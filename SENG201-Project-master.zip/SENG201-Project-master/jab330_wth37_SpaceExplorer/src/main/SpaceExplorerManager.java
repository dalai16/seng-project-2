/**
 * The SpaceExplorerManager is the main game environment which holds all the
 * key variables and methods of the game. the class is called everytime 
 * another window is launched and when variables are called or changed.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class SpaceExplorerManager {
	
	/**
	 * Initialize the crew class
	 */
	private Crew crew = new Crew();
	/**
	 * Initialize inventory class
	 */
	private Inventory inventory = new Inventory();
	/**
	 * The amount of days adventure will last
	 */
	private int adventureDays;
	/**
	 * The amount of pieces to find
	 */
	private int requiredPieces;
	/**
	 * The size of the crew
	 */
	private int crewSize;
	/**
	 * The day current day of the adventure
	 */
	private int currentDay = 1;
	/**
	 * The index of the selected member
	 */
	private int currentMember = 0;
	/**
	 * Boolean of if the transporter piece is found on the current planet
	 */
	private boolean alreadyFound = false;
	/**
	 * The current game score
	 */
	private int currentScore = 0;
	/**
	 * Initialize the name of the planets
	 */
	ArrayList<String> planets = new ArrayList<>(Arrays.asList("Hocilea", "Sebanus", "Xibbion", "Tulriuq", "Sacarro", "Giebos", "Migetov", "Zeehiri", "Bryria R47C", "Brosie 72K", "Pagnouhiri", "Eccocury", "Tagao", "Lanryke", "Haewei", "Chehiri", "Choxuhines", "Phakicarro", "Dilles I", "Grosie 98R", "Cegnepra", "Ephobos", "Ecrov", "Succars", "Hanides", "Moilea", "Mixecarro", "Treeliv", "Golla C7DZ", "Dora 933", "Zedoiter", "Ruccaoruta", "Choccorth", "Esurn", "Xetania", "Poutis", "Briohiri", "Llezinope", "Trara 689A", "Strippe AQ1P"));
	Random rand = new Random();
	/**
	 * The name of the currentPlanet
	 */
	private String currentPlanet = planets.get(rand.nextInt(planets.size()));
	
	/**
	 * shows the number of plague cure items currently on-hand
	 * @return	number of plague cure items
	 */
	public int getPlaguecurecount() {
		return inventory.getPlaguecurecount();
	}
	
	/**
	 * updates the number of plague cure items currently on-hand
	 * @param plaguecurecount	sets the current count of plague cure items  
	 */
	public void setPlaguecurecount(int plaguecurecount) {
		inventory.setPlaguecurecount(plaguecurecount);
	}
	
	/**
	 * shows the number of plaster items currently on-hand
	 * @return	number of plaster items
	 */
	public int getPlastercount() {
		return inventory.getPlastercount();
	}
	
	/**
	 * updates the number of plaster items currently on-hand
	 * @param plastercount	sets the current count of plaster items  
	 */
	public void setPlastercount(int plastercount) {
		inventory.setPlastercount(plastercount);
	}
	
	/**
	 * shows the number of medkit items currently on-hand
	 * @return	number of medkit items
	 */
	public int getMedkitcount() {
		return inventory.getMedkitcount();
	}
	
	/**
	 * updates the number of medkit items currently on-hand
	 * @param medkitcount	sets the current count of medkit items  
	 */
	public void setMedkitcount(int medkitcount) {
		inventory.setMedkitcount(medkitcount);
	}
	
	/**
	 * shows the number of bandage items currently on-hand
	 * @return	number of bandage items
	 */
	public int getBandagecount() {
		return inventory.getBandagecount();
	}
	
	/**
	 * updates the number of bandage items currently on-hand
	 * @param bandagecount	sets the current count of bandage items  
	 */
	public void setBandagecount(int bandagecount) {
		inventory.setBandagecount(bandagecount);
	}
	
	/**
	 * shows the number of rice items currently on-hand
	 * @return	number of rice items
	 */
	public int getRicecount() {
		return inventory.getRicecount();
	}
	
	/**
	 * updates the number of rice items currently on-hand
	 * @param ricecount	sets the current count of rice items  
	 */
	public void setRicecount(int ricecount) {
		inventory.setRicecount(ricecount);
	}
	
	/**
	 * shows the number of ramen items currently on-hand
	 * @return	number of ramen items
	 */
	public int getRamencount() {
		return inventory.getRamencount();
	}
	
	/**
	 * updates the number of ramen items currently on-hand
	 * @param ramencount	sets the current count of ramen items  
	 */
	public void setRamencount(int ramencount) {
		inventory.setRamencount(ramencount);
	}
	
	/**
	 * shows the number of brownies items currently on-hand
	 * @return	number of brownies items
	 */
	public int getBrowniescount() {
		return inventory.getBrowniescount();
	}
	
	/**
	 * updates the number of brownies items currently on-hand
	 * @param browniescount	sets the current count of brownies items  
	 */
	public void setBrowniescount(int browniescount) {
		inventory.setBrowniescount(browniescount);
	}
	
	/**
	 * shows the number of hamburger items currently on-hand
	 * @return	number of hamburger items
	 */
	public int getHamburgercount() {
		return inventory.getHamburgercount();
	}
	
	/**
	 * updates the number of plaster items currently on-hand
	 * @param hamburgercount the current count of plaster items  
	 */
	public void setHamburgercount(int hamburgercount) {
		inventory.setHamburgercount(hamburgercount);
	}
	
	/**
	 * shows the number of nutrition bar items currently on-hand
	 * @return	number of nutrition bar items
	 */
	public int getNutritionbarcount() {
		return inventory.getNutritionbarcount();
	}
	
	/**
	 * updates the number of nutrition bar items currently on-hand
	 * @param nutritionbarcount	sets the current count of nutrition items  
	 */
	public void setNutritionbarcount(int nutritionbarcount) {
		inventory.setNutritionbarcount(nutritionbarcount);
	}
	
	/**
	 * shows the number of chips items currently on-hand
	 * @return	number of chips items
	 */
	public int getChipscount() {
		return inventory.getChipscount();
	}
	
	/**
	 * updates the number of chips items currently on-hand
	 * @param chipscount	sets the current count of plaster items  
	 */
	public void setChipscount(int chipscount) {
		inventory.setChipscount(chipscount);
	}
	/**
	 * returns the number of days the player's adventure will last for
	 * @return	the number of adventure days
	 */
	public int getAdventureDays() {
		return adventureDays;
	}
	
	/**
	 * sets the number of days the player's adventure will last for
	 * @param days	amount of days
	 */
	public void setAdventureDays(int days) {
        adventureDays = days;
	}
	
	/**
	 * returns the number of transporter pieces the player needs to find.
	 * @return	needed transporter pieces
	 */
	public int getPiecesAmount() {
		return requiredPieces;
	}
	
	/**
	 * sets the number of transporter pieces the player needs to find.
	 * @param pieces  number of pieces needed
	 */
	public void setPiecesAmount(int pieces) {
        requiredPieces = pieces;
    }
	
	/**
	 * returns the amount of days the adventure is currently on
	 * @return	amount of current days
	 */
	public int getCurrentDay() {
		return currentDay;
	}
	
	/**
	 * sets the current day to the amount of days the adventure has lasted for
	 * @param day	amount of current days
	 */
	public void setCurrentDay(int day) {
		currentDay = day;
	}
	
	/**
	 * gets the amount of money the crew owns on-hand - used to buy items
	 * @return the current amount of money 
	 */
	public int getCurrentMoney() {
	    return crew.getMoneyAmount();
	}
	
	/**
	 * sets the amount of money the crew owns
	 * @param amount  changes money to amount
	 */
	public void setMoneyAmount(int amount) {
	    crew.setMoneyAmount(amount);
	}
	/**
	 * gets the number of transporter pieces the crew has currently found
	 * @return	amount of transporter pieces found
	 */
	public int getCurrentPieces() {
		return crew.getPartsAmount();
	}
	/**
	 * sets the current number of transporter pieces the crew has currently found
	 * @param piece	changes amount of pieces to piece.
	 */
	public void setCurrentPieces(int piece) {
		crew.setPartsAmount(piece);
	}
	
	/**
	 * the getCrew method returns the current crew class on board
	 * which contains the list of crew members and the ArrayLists 
	 * for the items owned
	 * @return crew class type 
	 */
	public Crew getCrew() {
		return crew;
	}
	
	/**
	 * returns the crew member located at the given index of the crew member list
	 * @param index index of crew member in crew member list
	 * @return the crewMembers object at that index
	 */
	public String getCrewName(int index) {
		return crew.getCrewList().get(index).getName();
	}
	
	/**
	 * returns the CrewMembers type of a crew member at a given  index
	 * @param index 	index of crew member list
	 * @return the class type of that crew member
	 */
	public CrewMembers getCrewClass(int index) {
		return crew.getCrewList().get(index);
	}
	
	/**
	 * returns health of crew member at given crew member list index
	 * @param index		index of crew member list
	 * @return	the current health of that member
	 */
	public int getCrewHealth(int index) {
		return crew.getCrewList().get(index).getHealth();
	}
	/**
	 * sets the health of a crew member in member list at given list index
	 * @param index  index of crew member
	 * @param num	amount of health that is set to
	 */
	public void setCrewHealth(int index, int num) {
		crew.getCrewList().get(index).setHealth(num);
	}
	/**
	 * gets the hunger of a crew member in member list at given list index
	 * @param index		index of crew member
	 * @return	the hunger level of that member
	 */
	public int getCrewHunger(int index) {
		return crew.getCrewList().get(index).getHunger();
	}
	/**
	 * sets the hunger level of a crew member at specified list index
	 * @param index		position of crew member in crew list
	 * @param num	amount of hunger set
	 */
	public void setCrewHunger(int index, int num) {
		crew.getCrewList().get(index).setHunger(num);
	}
	/**
	 * gets the tiredness of a crew member by index in crew list
	 * @param index  index of crew member
	 * @return	tiredness of crew member
	 */
	public int getCrewTiredness(int index) {
		return crew.getCrewList().get(index).getTiredness();
	}
	/**
	 * sets the tiredness of a crew member by index in crew list
	 * @param index	index of crew member
	 * @param num new tiredness of crew member
	 */
	public void setCrewTiredness(int index, int num) {
		crew.getCrewList().get(index).setTiredness(num);
	}
	
	/**
	 * returns a boolean value of whether the crew member
	 * at given index has space plague or not
	 * @param index index of crew member list
	 * @return has space plague
	 */
	public boolean getIsDiseased(int index) {
		return crew.getCrewList().get(index).getDiseased();
	}
	
	/**
	 * sets the crew member at given index of crew list 
	 * a value of type boolean if they have space plague or not
	 * @param index  index of crew member list
	 * @param bool  are they diseased
	 */
	public void setIsDiseased(int index, boolean bool) {
		crew.getCrewList().get(index).setDiseased(bool);
	}
	
	/**
	 * returns the amount of days a member at crew index has been diseased for
	 * damage taken by disease scales with day amount
	 * @param index index of crew list
	 * @return amount of days plagued
	 */
	public int getDaysPlagued(int index) {
		return crew.getCrewList().get(index).getDaysPlagued();
	}
	
	/**
	 * sets days plagued of crew member at given index
	 * @param index  index of crew list
	 * @param num  number of days plagued
	 */
	public void setDaysPlagued(int index, int num) {
		crew.getCrewList().get(index).setDaysPlagued(num);
	}
	
	/**
	 * returns the number of action points left for crew at crew index
	 * @param index  index of crew list
	 * @return	current action points of member
	 */
	public int getCrewActionPoints(int index) {
		return crew.getCrewList().get(index).getActionPoints();
	}
	
	/**
	 * sets the number of action points of member at crew index
	 * @param index		index of member in crew list
	 * @param num	amount of action points
	 */
	public void setCrewActionPoints(int index, int num) {
		crew.getCrewList().get(index).setActionPoints(num);
	}
	
	/**
	 * returns the repairing level of member at crew list index
	 * @param index  index of crew member
	 * @return  the repairing level
	 */
	public int getRepairLevel(int index) {
		return crew.getCrewList().get(index).getRepairing();
	}
	/**
	 * returns the foraging level of member at crew list index
	 * @param index  index of crew member
	 * @return  the foraging level
	 */
	public int getForagingLevel(int index) {
		return crew.getCrewList().get(index).getForaging();
	}
	
	/**
	 * returns the number of crew members aboard
	 * @return number of crew members
	 */
	public int getCrewSize() {
		return crewSize;
	}
	
	/**
	 * sets the number of crew members to specified amount
	 * @param num size of crew
	 */
	public void setCrewSize(int num) {
        crewSize = num;
    }
	
	/**
	 * returns the current member selected to perform an action
	 * @return  the index of current selected member in crew list
	 */
	public int getCurrentMember() {
		return currentMember;
	}
	
	/**
	 * sets the index of current member in crew list
	 * @param num position of current member
	 */
	public void setCurrentMember(int num) {
		currentMember = num;
	}
	
	/**
	 * returns the current game score of the player
	 * @return game score
	 */
	public int getCurrentScore() {
		return currentScore;
	}

	/**
	 * sets the players current game score to given amount
	 * @param num  set current game score
	 */
	public void setCurrentScore(int num) {
		currentScore = num;
	}
	/**
	 * returns the list of possible planet names the crew can land on
	 * @return list of planets
	 */
	public ArrayList<String> getPlanetList() {
		return planets;
	}
	/**
	 * sets the planet list to updated list
	 * @param list  new list of landable planets
	 */
    public void setPlanetList(ArrayList<String> list) {
    	planets = list;
    }
    
    /**
     * returns list of medical items the crew owns
     * @return  list of medical items
     */
    public ArrayList<Medical> getMedicalList() {
    	return crew.getMedicalList();
    }
    
    /**
     * returns list of food items the crew owns
     * @return  list of food items
     */
    public ArrayList<Food> getFoodList() {
    	return crew.getFoodList();
    }
    
    /**
     * boolean value of if the transporter part has been found
     * on current planet or not
     * @return has part been found yet
     */
	public boolean getAlreadyFound() {
		return alreadyFound;
	}
	/**
	 * sets boolean value of if a piece has been found on current planet or not
	 * @param alreadyFound  has been found
	 */
	public void setAlreadyFound(boolean alreadyFound) {
		this.alreadyFound = alreadyFound;
	}
	
	/**
	 * returns the name of the ship
	 * @return ship name
	 */
	public String getShipName() {
		return crew.getShipName();
	}
	
	/**
	 * sets the name of ship
	 * @param name  set ship name
	 */
	public void setShipName(String name) {
		crew.setShipName(name);
	}
	/**
	 * add a crew member into the crew list
	 * @param object crew member 
	 */
	public void addCrewMember(Object object) {
        crew.addCrewMember(object);
    }
	/**
	 * returns the amount of shield the ship has
	 * @return  amount of ship shield
	 */
	public int getShipShield() {
		return crew.getShieldAmount();
	}
	
	/**
	 * sets the ship shield to given amount
	 * @param num amount of shield
	 */
	public void setShipShield(int num) {
		crew.setShieldAmount(num);
	}
	
	/**
	 * returns the current planet the crew is on
	 * @return current planet
	 */
	public String getCurrentPlanet() {
		return currentPlanet;
	}
	/**
	 * sets the current planet the crew is on
	 * @param currentPlanet planet crew is on
	 */
	public void setCurrentPlanet(String currentPlanet) {
		this.currentPlanet = currentPlanet;
	}
	
	/**
	 * launches a new startup screen
	 */
	public void launchStartupScreen() {
		new StartupScreen(this);
	}
	/**
	 * closes start up screen
	 * @param startupWindow startupWindow 
	 */
	public void closeStartupScreen(StartupScreen startupWindow) {
		startupWindow.closeWindow();
	}
	
	/**
	 * launches crew creation screen
	 */
	public void launchCrewCreationScreen() {
		new CrewCreationScreen(this);
	}
	
	/**
	 * closes crew creation window
	 * @param crewcreationWindow crewcreationWindow
	 */
	public void closeCrewCreationScreen(CrewCreationScreen crewcreationWindow) {
		crewcreationWindow.closeWindow();
	}
	/**
	 * launch game screen
	 */
	public void launchGameScreen() {
		new GameScreen(this);
	}
	/**
	 * launch inventory screen
	 */
	public void launchInventoryScreen() {
		new InventoryScreen(this);
	}
	/**
	 * close game screen
	 * @param gameWindow gameWindow
	 */
	public void closeGameScreen(GameScreen gameWindow) {
		gameWindow.closeWindow();
	}
	/**
	 * close inventory window
	 * @param inventoryWindow nventoryWindow
	 */
	public void closeInventoryScreen(InventoryScreen inventoryWindow) {
		inventoryWindow.closeWindow();
	}
	/**
	 * launch outpost screen
	 */
	public void launchOutpostScreen() {
		new OutpostScreen(this);
	}
	
	/**
	 * close outpost screen
	 * @param OutpostWindow OutpostWindow
	 */
	public void closeOutpostScreen(OutpostScreen OutpostWindow) {
		OutpostWindow.closeWindow();
	}
	/**
	 * launch pilot screen
	 */
	public void launchPilotScreen() {
		new PilotScreen(this);
	}
	/**
	 * close pilot screen
	 * @param PilotWindow PilotWindow
	 */
	public void closePilotScreen(PilotScreen PilotWindow) {
		PilotWindow.closeWindow();
	}
	/**
	 * launch end screen
	 */
	public void launchEndScreen() {
		new EndScreen(this);
	}
	/**
	 * close end screen
	 * @param endWindow endWindow
	 */
	public void closeEndScreen(EndScreen endWindow) {
		endWindow.closeWindow();
	}
	/**
	 * creates new SpaceExplorerManager class instance and launches 
	 * startup screen to initiate game.
	 * @param args Main
	 */
	public static void main(String[] args) {
		SpaceExplorerManager manager = new SpaceExplorerManager();
		manager.launchStartupScreen();
	}

}
