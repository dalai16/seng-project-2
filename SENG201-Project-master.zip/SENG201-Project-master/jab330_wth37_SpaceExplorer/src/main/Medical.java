/**
 * The Medical class intantiates new medical items that the crew can use
 * to restore health and cure space plague.
 * also stores the name of the item and determines heal and market value.
 * @author: Jack Brokenshire
 * @author: William Huang
 */
package main;

public class Medical {
	
	/**
	 * The name of item
	 */
	String itemName;

	/**
	 * constuctor that creates a new type of medical object when called with a string to determine type 
	 * @param name The name of the medical item
	 */
	public Medical(String name) {
		itemName = name;
	}
	
	/**
	 * returns the string of the item
	 */
	public String toString() {
		return itemName;
	}
	
	/**
	 * Returns the cost of the item based on the name and sets the heal value 
	 * @return a value of a certain item
	 */
	public int getCost() {
		if (itemName.equals("Plague Cure")) {
			return 50;
		}
		
		else if (itemName.equals("Plaster")) {
			return 20;
		}
		else if (itemName.equals("Bandage")) {
			return 40;
		}

		else {
			return 85;
		}
	}
}
