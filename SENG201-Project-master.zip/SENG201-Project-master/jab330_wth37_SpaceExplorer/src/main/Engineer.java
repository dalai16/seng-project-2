/**
 * The Engineer class inherits methods from the super class CrewMembers.
 * This therefore means less code is used as Engineer uses all
 * default variables within CrewMembers and only specifically
 * changes the required variables.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Engineer extends CrewMembers {
	
	/** Takes a String called name which is the chosen players name
	 * and calls the super of CrewMembers which sets foragingLevel to 1,
	 * repairingLevel to 5, healthLevel to 100, and the rest are set to default
	 * @param name The CrewMembers chosen name
	 */
	public Engineer(String name) {
		super(name, 1, 5, 100);
	}
	
	/**
	 * Returns the Egineer class as a string value
	 * @return The string version of Engineer
	 */
	public String toString() {
        return "Engineer";
    }

}
