/**
 * the pilot screen is a gui that allows the player to travel to other 
 * planets and find transporter parts.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */
package main;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JButton;

public class PilotScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	/**
	 * Stores the amount of JRadioButtons clicked
	 */
	private int clickCount = 0;
	/**
	 * Stores previous JRadioButton clicked
	 */
	private JRadioButton previous;
	/**
	 * Stores current JRadioButton clicked
	 */
	private JRadioButton current;
	
	/**
	 * PilotScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public PilotScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	/**
	 * closes pilot screen window
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PilotScreen window = new PilotScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PilotScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Pilot the ship");
		frame.setBounds(100, 100, 290, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * label saying choose two members to pilot (shipName)
		 */
		JLabel lblMemberSelect = new JLabel("Choose two members to pilot " + manager.getShipName());
		lblMemberSelect.setBounds(10, 11, 299, 14);
		frame.getContentPane().add(lblMemberSelect);
		
		/**
		 * button1 is selectable if player1 has action points, not 0 tiredness, and alive
		 */
		JRadioButton rdbtnPlayer1 = new JRadioButton(manager.getCrewName(0));
		rdbtnPlayer1.setBounds(10, 50, 109, 23);
		frame.getContentPane().add(rdbtnPlayer1);
		if (manager.getCrewHealth(0) <= 0) {
			rdbtnPlayer1.setEnabled(false);
		}
		if (manager.getCrewActionPoints(0) == 0) {
			rdbtnPlayer1.setEnabled(false);
		}
		if(manager.getCrewTiredness(0) == 0) {
			rdbtnPlayer1.setEnabled(false);
		}
		
		/**
		 * button2 is selectable if player2 has action points, not 0 tiredness, and alive
		 */
		JRadioButton rdbtnPlayer2 = new JRadioButton(manager.getCrewName(1));
		rdbtnPlayer2.setBounds(129, 50, 109, 23);
		frame.getContentPane().add(rdbtnPlayer2);
		if (manager.getCrewHealth(1) <= 0) {
			rdbtnPlayer2.setEnabled(false);
		}
		if (manager.getCrewActionPoints(1) == 0) {
			rdbtnPlayer2.setEnabled(false);
		}
		if(manager.getCrewTiredness(1) == 0) {
			rdbtnPlayer2.setEnabled(false);
		}
		
		/**
		 * button3 is selectable if player3 has action points, not 0 tiredness, and alive
		 * button 3 hidden if crew size is 2
		 */
		JRadioButton rdbtnPlayer3 = new JRadioButton();
		rdbtnPlayer3.setBounds(10, 87, 109, 23);
		frame.getContentPane().add(rdbtnPlayer3);
		if (manager.getCrewSize() == 2) {
			rdbtnPlayer3.setVisible(false);
		}
		else {
			rdbtnPlayer3.setText(manager.getCrewName(2));
			if (manager.getCrewHealth(2) <= 0) {
			rdbtnPlayer3.setEnabled(false);
			}
			if (manager.getCrewActionPoints(2) == 0) {
				rdbtnPlayer3.setEnabled(false);
			}
			if(manager.getCrewTiredness(2) == 0) {
				rdbtnPlayer3.setEnabled(false);
			}
		}
		
		/**
		 * button4 is selectable if player4 has action points, not 0 tiredness, and alive
		 * button4 is hidden if crew size is 2 or 3
		 */
		JRadioButton rdbtnPlayer4 = new JRadioButton();
		rdbtnPlayer4.setBounds(129, 87, 109, 23);
		frame.getContentPane().add(rdbtnPlayer4);
		if (manager.getCrewSize() == 2) {
			rdbtnPlayer4.setVisible(false);
		}
		else if (manager.getCrewSize() == 3) {
			rdbtnPlayer4.setVisible(false);
			rdbtnPlayer3.setText(manager.getCrewName(2));
		}
		
		else {
			rdbtnPlayer3.setText(manager.getCrewName(2));
			rdbtnPlayer4.setText(manager.getCrewName(3));
			if (manager.getCrewHealth(3) <= 0) {
				rdbtnPlayer4.setEnabled(false);
			}
			if (manager.getCrewActionPoints(3) == 0) {
				rdbtnPlayer4.setEnabled(false);
			}
			if(manager.getCrewTiredness(3) == 0) {
				rdbtnPlayer4.setEnabled(false);
			}
		}
		/**
		 * updates click count previous and current to see the recent crew members selected
		 * sets the most recent 2 crew members selected as pilots
		 */
		rdbtnPlayer1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setClickCount(getClickCount() + 1);
				if(getClickCount() == 2) {
					setPrevious(current);
				}
				else if(getClickCount() == 3) {
					previous.setSelected(false);
					setPrevious(current);
					setClickCount(getClickCount() - 1);
				}
				setCurrent(rdbtnPlayer1);
			}
		});
		
		/**
		 * updates click count previous and current to see the recent crew members selected
		 * sets the most recent 2 crew members selected as pilots
		 */
		rdbtnPlayer2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setClickCount(getClickCount() + 1);
				if(getClickCount() == 2) {
					setPrevious(current);
				}
				else if(getClickCount() == 3) {
					previous.setSelected(false);
					setPrevious(current);
					setClickCount(getClickCount() - 1);
				}
				setCurrent(rdbtnPlayer2);

			}
		});
		
		/**
		 * updates click count previous and current to see the recent crew members selected
		 * sets the most recent 2 crew members selected as pilots
		 */
		rdbtnPlayer3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setClickCount(getClickCount() + 1);
				if(getClickCount() == 2) {
					setPrevious(current);
				}
				else if(getClickCount() == 3) {
					previous.setSelected(false);
					setPrevious(current);
					setClickCount(getClickCount() - 1);
				}
				setCurrent(rdbtnPlayer3);
			}
		});
		
		/**
		 * updates click count previous and current to see the recent crew members selected
		 * sets the most recent 2 crew members selected as pilots
		 */
		rdbtnPlayer4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setClickCount(getClickCount() + 1);
				if(getClickCount() == 2) {
					setPrevious(current);
				}
				else if(getClickCount() == 3) {
					previous.setSelected(false);
					setPrevious(current);
					setClickCount(getClickCount() - 1);
				}
				setCurrent(rdbtnPlayer4);
			}
		});
		
		/**
		 * returns back to Gamescreen and closes pilotscreen
		 * when button is clicked
		 */
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				closeWindow();
				manager.launchGameScreen();
			}
		});
		btnBack.setBounds(10, 127, 89, 23);
		frame.getContentPane().add(btnBack);
		
		/**
		 * 2 selected crew members take an action point to fly to a new random planet
		 * landable planets are updated 
		 */
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (getClickCount() == 2) {
					if (rdbtnPlayer1.isSelected()) {
						manager.setCrewActionPoints(0, manager.getCrewActionPoints(0) - 1);
					}
					if (rdbtnPlayer2.isSelected()) {
						manager.setCrewActionPoints(1, manager.getCrewActionPoints(1) - 1);
					}
					if (rdbtnPlayer3.isSelected()) {
						manager.setCrewActionPoints(2, manager.getCrewActionPoints(2) - 1);
					}
					if (rdbtnPlayer4.isSelected()) {
						manager.setCrewActionPoints(3, manager.getCrewActionPoints(3) - 1);
					}
					Random rand = new Random(); 
					manager.getPlanetList().remove(manager.getCurrentPlanet());
					manager.setPlanetList(manager.getPlanetList());
					manager.setCurrentPlanet(manager.getPlanetList().get(rand.nextInt(manager.getPlanetList().size())));
					manager.setAlreadyFound(false);
					JOptionPane.showMessageDialog(null, manager.getShipName() + " has now landed on " + manager.getCurrentPlanet());
					closeWindow();
					manager.launchGameScreen();
				}
			}
		});
		btnConfirm.setBounds(129, 127, 89, 23);
		frame.getContentPane().add(btnConfirm);
	}
	/**
	 * returns the click count to indicate number of pilots selected
	 * @return the click count
	 */
	public int getClickCount() {
		return clickCount;
	}
	/**
	 * sets the click count to specified number
	 * @param clickCount click amount
	 */
	public void setClickCount(int clickCount) {
		this.clickCount = clickCount;
	}
	/**
	 * returns the least recent pilot
	 * @return  button of least recent pilot
	 */
	public JRadioButton getPrevious() {
		return previous;
	}
	/**
	 * sets the least recent pilot
	 * @param previous set least recent pilot button
	 */
	public void setPrevious(JRadioButton previous) {
		this.previous = previous;
	}
	/**
	 * gets current button of recent pilot
	 * @return current pilot button
	 */
	public JRadioButton getCurrent() {
		return current;
	}
	
	/**
	 * sets current button of recent pilot
	 * @param current recent pilon button
	 */
	public void setCurrent(JRadioButton current) {
		this.current = current;
	}
}
