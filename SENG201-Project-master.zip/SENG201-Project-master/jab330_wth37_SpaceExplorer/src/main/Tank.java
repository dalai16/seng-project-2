/**
 * The Tank class is a crewMembers type that
 * extends the CrewMembers class.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Tank extends CrewMembers {
	
	/** Tank has weak foraging and repairing skills 
	 * but starts the game with 50 extra health than
	 * other crew members.
	 * call to CrewMembers constructor with given name,
	 * 2 foraging level and 2 repairing level
	 * @param name		crew member's name
	 */
	public Tank(String name) {
		super(name, 2, 2, 150);
	}
	
	/**
	 *  Returns the Tank class as a string value
	 *  @return		The string version of Tank
	 */
	public String toString() {
        return "Tank";
    }
}
