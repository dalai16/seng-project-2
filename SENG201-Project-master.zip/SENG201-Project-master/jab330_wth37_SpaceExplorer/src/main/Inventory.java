/**
 * the Inventory screen allows players to view their current
 * items, money and transporter parts on-hand.
 * they may also use items on members to consume.
 * getters and setters for each variable
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Inventory {
	
	/**
	 * The amount of plague cure
	 */
	private int plaguecurecount = 0;
	/**
	 * The amount of plasters
	 */
	private int plastercount = 0;
	/**
	 * The amount of medkits
	 */
	private int medkitcount = 0;
	/**
	 * The amount of bandages
	 */
	private int bandagecount = 0;
	/**
	 * The amount of rice
	 */
	private int ricecount = 0;
	/**
	 * The amount of ramen
	 */
	private int ramencount = 0;
	/**
	 * The amount of brownies
	 */
	private int browniescount = 0;
	/**
	 * The amount of hamburgers
	 */
	private int hamburgercount = 0;
	/**
	 * The amount of nutritionbars
	 */
	private int nutritionbarcount = 0;
	/**
	 * The amount of chips
	 */
	private int chipscount = 0;
	
	
	/**
	 * Returns the crews amount of plague cures
	 * @return The amount of plague cures
	 */
	public int getPlaguecurecount() {
		return plaguecurecount;
	}
	
	/**
	 * Sets the amount of plague cures
	 * @param plaguecurecount The amount of plague cures
	 */
	public void setPlaguecurecount(int plaguecurecount) {
		this.plaguecurecount = plaguecurecount;
	}
	
	/**
	 * Returns the crews amount of plasters
	 * @return The amount of plasters
	 */
	public int getPlastercount() {
		return plastercount;
	}
	
	/**
	 * Sets the amount of plasters
	 * @param plastercount The amount of plasters
	 */
	public void setPlastercount(int plastercount) {
		this.plastercount = plastercount;
	}
	
	/**
	 * Returns the crews amount of medkits
	 * @return The amount of medkits
	 */
	public int getMedkitcount() {
		return medkitcount;
	}
	
	/**
	 * Sets the amount of medkits
	 * @param medkitcount The amount of medkits
	 */
	public void setMedkitcount(int medkitcount) {
		this.medkitcount = medkitcount;
	}
	
	/**
	 * Returns the crews amount of bandages
	 * @return The amount of bandages
	 */
	public int getBandagecount() {
		return bandagecount;
	}
	
	/**
	 * Sets the amount of bandages
	 * @param bandagecount The amount of bandages
	 */
	public void setBandagecount(int bandagecount) {
		this.bandagecount = bandagecount;
	}
	
	/**
	 * Returns the crews amount of rice
	 * @return The amount of rice
	 */
	public int getRicecount() {
		return ricecount;
	}
	
	/**
	 * Sets the amount of rice
	 * @param ricecount The amount of rice
	 */
	public void setRicecount(int ricecount) {
		this.ricecount = ricecount;
	}
	
	/**
	 * Returns the crews amount of ramen
	 * @return The amount of ramen
	 */
	public int getRamencount() {
		return ramencount;
	}
	
	/**
	 * Sets the amount of raman
	 * @param ramencount The amount of raman
	 */
	public void setRamencount(int ramencount) {
		this.ramencount = ramencount;
	}
	
	/**
	 * Returns the crews amount of brownies
	 * @return The amount of brownies
	 */
	public int getBrowniescount() {
		return browniescount;
	}
	
	/**
	 * Sets the amount of brownies
	 * @param browniescount The amount of brownies
	 */
	public void setBrowniescount(int browniescount) {
		this.browniescount = browniescount;
	}
	
	/**
	 * Returns the crews amount of hamburgers
	 * @return The amount of hamburgers
	 */
	public int getHamburgercount() {
		return hamburgercount;
	}
	
	/**
	 * Sets the amount of hamburgers
	 * @param hamburgercount The amount of hamburgers
	 */
	public void setHamburgercount(int hamburgercount) {
		this.hamburgercount = hamburgercount;
	}
	
	/**
	 * Returns the crews amount of nutrition bars
	 * @return The amount of nutrition bars
	 */
	public int getNutritionbarcount() {
		return nutritionbarcount;
	}
	
	/**
	 * Sets the amount of nutrition bars
	 * @param nutritionbarcount The amount of nutrition bars
	 */
	public void setNutritionbarcount(int nutritionbarcount) {
		this.nutritionbarcount = nutritionbarcount;
	}
	
	/**
	 * Returns the crews amount of chips
	 * @return The amount of chips
	 */
	public int getChipscount() {
		return chipscount;
	}
	
	/**
	 * Sets the amount of chips
	 * @param chipscount The amount of chips
	 */
	public void setChipscount(int chipscount) {
		this.chipscount = chipscount;
	}
	
}
