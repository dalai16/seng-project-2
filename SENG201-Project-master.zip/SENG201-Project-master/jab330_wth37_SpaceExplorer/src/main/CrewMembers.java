/**
 * CrewMembers is the super class for the crew member types.
 * private variables are initialized to default values.
 * when a sub class is instantiated, their repairing and foraging values are adjusted
 * contains getter and setter methods for each crew member.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class CrewMembers {
	
	/**
	 * The name of the crew member
	 */
	private String playerName;
	/**
	 * The amount of action points the character has
	 */
	private int actionPoints = 2;
	/**
	 * The amount of hunger the character has remaining
	 */
	private int hungerLevel = 100;    
	/**
	 * The amount of health the character has remaining
	 */
	private int healthLevel;   
	/**
	 * The amount of tiredness the character has remaining
	 */
	private int tirednessLevel = 100; 
	/**
	 * The level of characters foraging
	 */
	private int foragingLevel;   
	/**
	 * The level of characters repair
	 */
	private int repairingLevel;  
	/**
	 * The status if character is diseased or not
	 */
	private boolean isDiseased = false;
	/**
	 * The amount of days the character has been plagued
	 */
	private int daysPlagued = 0;
	
	
	/**
	 * Constructor which is used to change the parameters of the
	 *  specific classes selected
	 * @param name The string name of player
	 * @param forage The integer foraging level
	 * @param repair The integer repair level
	 * @param health The integer health level
	 */
	public CrewMembers(String name, int forage, int repair, int health) {
		playerName = name;
		foragingLevel = forage;
		repairingLevel = repair;
		healthLevel = health;
	}
	
	/**
	 * Returns the the string of the playerName
	 * @return The String of playerName
	 */
	public String getName() {
		return playerName;
	}
	
	/**
	 * Sets the playerName to the inputed string name
	 * @param name The string name of the player
	 */
	public void setName(String name) {
		playerName = name;
	}
	
	/**
	 * Returns the string of the actionPoints
	 * @return The String of actionPoints
	 */
	public int getActionPoints() {
    	return actionPoints;
    }
	
	/**
	 * Sets the actionPoints to the inputed int num
	 * @param num The int num of the players action points
	 */
    public void setActionPoints(int num) {
    	if (num > 2) {
    		actionPoints = 2;
		}
		else if (num < 0) {
			actionPoints = 0;
		}
		else {
			actionPoints = num;
		}
    }
	
    /**
     * Returns the integer of the players hungerLevel
     * @return The int of hungerLevel
     */
	public int getHunger() {
		return hungerLevel;
	}
	
	/**
	 * Caps the hunger to 100 if set above 100
	 * Sets the hunger to 0 if set below 0
	 * Sets the hungerLevel to the int hunger
	 * @param hunger The int hunger of the players hunger level
	 */
	public void setHunger(int hunger) {
		if (hunger > 100) {
			hungerLevel = 100;
		}
		else if (hunger < 0) {
			hungerLevel = 0;
		}
		else {
        hungerLevel = hunger;
		}
    }
	
	/**
	 * Returns the integer of the players healthLevel
	 * @return The int of healthLevel
	 */
	public int getHealth() {
		return healthLevel;
	}
	
	/**
	 * Caps the health to 100 if set above 100
	 * Sets the health to 0 if set below 0
	 * Sets the healthLevel to the int health
	 * @param health The int health of the players health level
	 */
	public void setHealth(int health) {
		if (health > 100) {
			healthLevel = 100;
		}
		else if (health < 0) {
			healthLevel = 0;
		}
		else {
			healthLevel = health;
		}
    }
	
	/**
	 * Returns the integer of the players foragingLevel
	 * @return The int of foragingLevel
	 */
	public int getForaging() {
		return foragingLevel;
	}
	
	/**
	 * Returns the integer of the players reparingLevel
	 * @return The int of repairingLevel
	 */
	public int getRepairing() {
		return repairingLevel;
	}
	
	/**
	 * Returns the integer of the players tirednessLevel
	 * @return The int of tirednessLevel
	 */
	public int getTiredness() {
		return tirednessLevel;
	}
	
	/**
	 * Caps the tirednessLevel to 100 if set above 100
	 * Sets the tirednessLevel to 0 if set below 0
	 * Sets the tirednessLevel to the int tiredness
	 * @param tiredness The int tiredness of the players tiredness level
	 */
	public void setTiredness(int tiredness) {
		if (tiredness > 100) {
			tirednessLevel = 100;
		}
		else if (tiredness < 0) {
			tirednessLevel = 0;
		}
		else {
			tirednessLevel = tiredness;
		}
    }

	/**
	 * Returns true or false if the player isDiseased
	 * @return true if player diseased false if player is not diseased
	 */
	public boolean getDiseased() {
		return isDiseased;
	}
	
	/**
	 * Sets isDiseased true or false
	 * @param bool The boolean bool is either true or false
	 */
	public void setDiseased(boolean bool) {
		isDiseased = bool;
	}
	
	/**
	 * Returns the amount of days the player has been plagued
	 * @return The amount of days plagued
	 */
	public int getDaysPlagued() {
		return daysPlagued;
	}
	
	/**
	 * Sets the amount of days the player has been plagued
	 * @param num The amount of days plagued
	 */
	public void setDaysPlagued(int num) {
		if (num < 0) {
			daysPlagued = 0;
		}
		else {
			daysPlagued = num;
		}
	}

}
