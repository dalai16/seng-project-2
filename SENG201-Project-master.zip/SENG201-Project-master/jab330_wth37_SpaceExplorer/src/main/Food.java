/**
 * Food class
 *
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Food {
	/**
	 * holds the name of item which is refered to when toString() method is called
	 */
	String itemName;

	/**
	 * constructor that takes a string and sets it to itemName
	 * @param name name of item
	 */
	public Food(String name) {
		itemName = name;
	}

	/**
	 * returns string representation of item
	 */
	public String toString() {
		return itemName;
	}
	/**
	 * getCost() returns an integer value of the item
	 * the integer is also interpreted as the amount of health restored
	 * when consumed from inventory.
	 * @return values
	 */
	public int getCost() {
		if (itemName.equals("Rice")) {
			return 50;
		}
		else if (itemName.equals("Brownies")) {
			return 20;
		}
		else if (itemName.equals("Nutrition Bar")) {
			return 30;
		}
		else if (itemName.equals("Hamburger")) {
			return 60;
		}

		else if (itemName.equals("Chips")) {
			return 10;
		}
		return 40;
	}
}
