/**
 * The Medic class inherits methods from the super class CrewMembers.
 * This therefore means less code is used as Medic uses all
 * default variables within CrewMembers and only specifically
 * changes the required variables.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Medic extends CrewMembers {
	
	/** Takes a String called name which is the chosen players name
	 * and calls the super of CrewMembers which sets foragingLevel to 2,
	 * repairingLevel to 2, healthLevel to 100, and the rest are set to default
	 * @param name string name
	 */
	public Medic(String name) {
		super(name, 2, 2, 100);
	}
	
	/**
	 *  Returns the Medic class as a string value
	 *  @return	The string version of medic
	 */
	public String toString() {
        return "Medic";
    }

}
