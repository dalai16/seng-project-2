/**
 * The scout class inherits the CrewMembers class.
 * it calls super with max foraging level but min repairing level and default 100 health.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

public class Scout extends CrewMembers {
	/**
	 * call to super with chosen name, level 5 foraging, level 1 repairing, 100 health
	 * @param name given name string
	 */
	public Scout(String name) {
		super(name, 5, 1, 100);
	}
	/**
	 * string representation of crew type
	 */
	public String toString() {
        return "Scout";
    }
}
