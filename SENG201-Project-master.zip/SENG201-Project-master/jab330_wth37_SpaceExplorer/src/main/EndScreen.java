/**
 * EndScreen is a graphical interface.
 * Displays the ships name, amount of days
 * the crew lasted, the amount of transporter
 * pieces found, and a game score.
 * 
 * @author: Jack Brokenshire
 * @author: William Huang
 */

package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class EndScreen {
	
	/**
	 * Initializes the current screen as a frame
	 */
	private JFrame frame;
	/**
	 * Initializes SpaceExplorerManager as manager which is the game environment
	 */
	private SpaceExplorerManager manager;
	
	/**
	 * EndScreen takes a class SpaceExplorerManager and
	 * sets manager equal to it then sets the frame as visible
	 * @param incomingManager The incoming manager of class
	 */
	public EndScreen(SpaceExplorerManager incomingManager) {
		manager = incomingManager;
		initialize();
		frame.setVisible(true);
	}
	
	/**
	 * closeWindow disposes the current frame in use
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Launch the application.
	 * @param args arg
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EndScreen window = new EndScreen();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EndScreen() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("End Game");
		frame.setBounds(100, 100, 350, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		/**
		 * Displays the end game information
		 */
		manager.setCurrentScore(((manager.getAdventureDays() - manager.getCurrentDay()) * 300) + ((manager.getPiecesAmount() - manager.getCurrentPieces()) * 500));
		JLabel lblEndScore = new JLabel("<html>Shipname: " + manager.getShipName() + "<br><br> Number of days taken: " + manager.getCurrentDay() + "<br><br> Pieces found: " + manager.getCurrentPieces() + "<br><br> Your final score was : " + manager.getCurrentScore() + " points. </html>");
		lblEndScore.setBounds(10, 10, 198, 109);
		frame.getContentPane().add(lblEndScore);
	}
}
